segate.zip contains the following:
1) "bin" folder containing
	i) bytecode of the SEGATE tool, bundled along with two faulty methods from our dataset to generate strings for.
	ii) The necessary jars needed to the run the implementation (except the soot jar that is required to be downloaded separately).
The bytecode of the following files has been included in the bin folder. We are sharing the source code only for understanding purpose.
3) TestGenerateStrings.java with test oracles using different components of SEGATE.
4) Other .java files contain the programs invoking the faulty methods to test. 
*****************

Requires: Java 8 on the system

*****************

Test generation to reveal bug id- Guava-1462
*****************
The tool is expected to generate test inputs to test the getFileExtension method which has been discussed in the Motivating Example section of the paper.

Execution steps:
1) Dependency- Download the jar for soot available here: https://soot-build.cs.uni-paderborn.de/public/origin/master/soot/soot-master/3.1.0/build/sootclasses-trunk-jar-with-dependencies.jar
2) Unzip segate.zip to extract the files.
3) Move the soot jar to the bin folder in the extracted "segate" directory.
4) Open the command prompt and change the directory to the "segate" directory
5) Execute the following command, where the argument '1' indicates executing the first test program: 
	For Linux: java -cp bin:bin/*:. StringGenerator.TestGenerateStrings 1
	For Windows: java -cp bin;bin/*;. StringGenerator.TestGenerateStrings 1
*****************

Output Description:

The output is expected to show the working of Soot showing derivation of regular expression(r_impl) from the program through static analysis.
The regular expression (r_spec) passed to the Test Generator Component would show the sample test strings getting generated. One of the generated test strings "S:\44 44-.--\" reveals the defect for the method under test as discussed in the paper.
The r_spec has been derived from the documentation and already included as input to the tool.

Other test programs:
To run the test program for revelation of Bug id- Guava-1557, follow the same instructions as above, passing the argument value as 2, instead of 1 in step 5.
The output will generate a test-strings with at least one of them being an IP address with a scope-id(e.g. 0444:4444:4444:4444:4444:4444:8444:4444%4)
Note:
Due to space constraints, we have bundled only the Guava library along with the tool in this setup.
1) To execute the remaining test-programs, you may download the source for other libraries from github. The excel sheet shared on the site contains links to the buggy source codes from where the source of library version containing the bug may be downloaded. The excel sheet is available at http://www.gapdetector.epizy.com/wp/wp-content/uploads/2018/08/String-related-relevant-bugs.xlsx
2) Build the source on eclipse to generate .class files.
3) Add their project folder containing the .class files to the segate folder.
4) Compile all the source files with naming convention as Test_<...>.java
5) Test-oracles for these remaining test programs are available in TestGenerateStrings.java- you may uncomment the line corresponding to the bug-id for which you would like to generate the defect revealing strings and then compile the source file to generate the .class.
6) Replace TestGenerateStrings.class in bin/StringGenerator/ with the newly generated TestGenerateStrings.class. Execute the following command:
	For Linux: java -cp bin:bin/*:. StringGenerator.TestGenerateStrings
	For Windows: java -cp bin;bin/*;. StringGenerator.TestGenerateStrings