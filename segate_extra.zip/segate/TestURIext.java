package DeriveRegex;

import org.springframework.web.util.UriUtils;

public class TestURIext {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Spring-framework-15786, pullreq-1480
		//System.out.println(UriUtils.extractFileExtension("www.fb.com/xxx/yyy.json#aaa?bbb"));
		System.out.println(UriUtils.extractFileExtension("!!$%44!$%CC'.=Y_s"));
		
	}

}
