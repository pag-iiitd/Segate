package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashSet;
import java.util.Iterator;

import org.springframework.boot.test.EnvironmentTestUtils;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.StandardEnvironment;

import com.google.api.client.http.UrlEncodedParser;

public class TestURLParser {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//Google http-client392
	    Object actual = new Object();
	    StringReader s=new StringReader("p=4&q=1&a=x&p=3&b=y&c=z&d=v&q=2&p=5&o=object");
	    UrlEncodedParser.parse(s, actual);
	    /*UrlEncodedParser.parse("Lsf9CUFLy%5CZ+8T5=L8U9%9C=",actual);
	    UrlEncodedParser.parse("L=Cs8ZTL9%58&ZCs%5F==f+FUy5",actual);
	    UrlEncodedParser.parse("LZ+L5FUCy8f9%95CL%8FFf+8Z=LF=ysT5",actual);
*/
	}

	public static void testall(String fname,HashSet<String> teststr)
	{
		Object actual = new Object();
		
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+UrlEncodedParser.parse_d(new StringReader(s), actual)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
