package DeriveRegex;

import org.apache.commons.validator.routines.UrlValidator;

public class TestValidUrl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//VALIDATOR-411,420
		System.out.println((new UrlValidator()).isValid("http://example.com/serach?address=Main Avenue"));
	}

}
