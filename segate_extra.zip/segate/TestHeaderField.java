package DeriveRegex;

import org.apache.commons.net.smtp.SimpleSMTPHeader;

public class TestHeaderField {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//NET-582
		SimpleSMTPHeader hdr = new SimpleSMTPHeader("from@here.invalid", null, null);
		System.out.println(hdr.toString("from@here.invalid", null, null,null));
	}

}
