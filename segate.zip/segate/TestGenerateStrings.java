package StringGenerator;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import dk.brics.automaton.Automaton;
import dk.brics.automaton.AutomatonMatcher;
import dk.brics.automaton.BasicOperations;
import dk.brics.automaton.MinimizationOperations;
import dk.brics.automaton.RegExp;
import dk.brics.automaton.RunAutomaton;
import dk.brics.automaton.SpecialOperations;
import dk.brics.automaton.State;
import dk.brics.automaton.StatePair;
import dk.brics.automaton.Transition;
import DeriveRegex.*;

public class TestGenerateStrings {
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		Runtime runtime = Runtime.getRuntime();
	    long startTime = System.currentTimeMillis();
	 
	    test_fileext(args);	    
	    long endTime = System.currentTimeMillis();
	    float duration = (float) ((endTime - startTime)/1000.0);  

		long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
	
	    System.out.println("Memory Usage: "+new MemoryUsage().getSettledUsedMemory()/1000000.0);
		System.out.println("Time taken:" + duration);
				
	}
	
	
	static void test_fileext(String[] args) throws Exception
	{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestFileExtension";
		String validchar="[a-zA-Z0-9\\-\\\\_\\.\\~:\\|/ ]";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\-_\\.\\~\\\\ ]",validchar);//cannot allow some spl char to occur anywhere, hence not including in charset
		String filepath_spec;
		String digit    = "([0-9])";
	    String upalpha  = "([A-Z])";
	    String lowalpha = "([a-z])";
	    String alpha         = "("+lowalpha+"|"+upalpha+")";
	    String alphanum      = "("+alpha+"|"+digit+")";
	    String hex           = "("+digit+"|[A-Fa-f])";
	    String pct_encoded   = "(%"+hex+hex+")";
	    String mark          = "([\\-_\\~])";//` is for non-special .
	    String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ \\.]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
	    String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
	    String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
	    String segment         = "("+unreserved+")*";//replaced pchar
	    String segment_nz         = "("+unreserved+")+";//replaced pchar
	    String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(\\.))+)?)?)";
	    String relativepath="("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(\\.))+)?)";
	    String drivemarker= "([:\\|])";
	    String driveletter="("+alpha+"("+drivemarker+")?)";
	    String path_abs_win="("+driveletter+path_absolute+")";
	    String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+")(\\#("+unreserved+")+)?)";//# to denote spl case of : as ads separator
		filepath_spec=localfile;
		
		System.out.println("r_spec: "+filepath_spec);
		
		//Enable to use recommendation system to compute r_spec (requires net connectivity)
		//filepath_spec=FetchRegex.getreg("file path");
		
		//Enable to test for Blackbox fuzz Test
		//test2(filepath_spec,"", new LinkedHashSet());
		
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		//for Segate execution
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			filepath_spec=filepath_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar);
			break;
			}
	}
	
	
	static HashSet<String> test(String specregex, String coderegex, LinkedHashSet<Character> specialChar)
	{
		Automaton p2=new RegExp(specregex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r2= new RunAutomaton(p2);
		Automaton p3=new RegExp(coderegex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r3= new RunAutomaton(p3);
	
		Automaton ex= getexclusive(specregex,coderegex);
		RunAutomaton rex=new RunAutomaton(ex);
		ArrayList<String> teststr=new StringGenerate(ex).generate(specialChar,rex,false);
		compliancewith(teststr,coderegex,specregex,rex);
		return new LinkedHashSet<String>(teststr);
	}
	
	static HashSet<String> test(String specregex, String coderegex, LinkedHashSet<Character> specialChar,String[] spl)
	{
		Automaton p2=new RegExp(specregex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r2= new RunAutomaton(p2);
		Automaton p3=new RegExp(coderegex,RegExp.ALL).toAutomaton(true);
		Automaton ex= getexclusive(specregex,coderegex);
		RunAutomaton rex=new RunAutomaton(ex);
		HashSet<String> teststr=new LinkedHashSet<String>(new StringGenerate(ex).generate(specialChar,rex,false));
		compliancewith(teststr,coderegex,specregex,rex,spl);
		return teststr;
		
	}
//For random testing comparison
	static HashSet<String> test2(String specregex, String coderegex, LinkedHashSet<Character> specialChar)
	{
		Automaton a1=new RegExp(specregex,RegExp.ALL).toAutomaton();
		RunAutomaton rex=new RunAutomaton(a1);
		ArrayList<String> teststr=new StringGenerate(a1).generate(specialChar,rex,true);
		compliancewith(teststr,coderegex,specregex,rex);
		return new LinkedHashSet<String>(teststr);

	}

	
	static Automaton getexclusive(String s1, String s2)
	{
		Automaton a1=new RegExp(s1,RegExp.ALL).toAutomaton();
		Automaton a2=new RegExp(s2,RegExp.ALL).toAutomaton();
		Automaton intersect=BasicOperations.intersection(a1, a2);
		Automaton union=BasicOperations.union(a1, a2);
		Automaton result= BasicOperations.minus(union, intersect);
		return result;
	}

	static void finddiff(String s, String rs, String rp)
	{
		Automaton p=new RegExp(rs,RegExp.ALL).toAutomaton();
		RunAutomaton r= new RunAutomaton(p);
		System.out.println("from first: "+ r+"\n"+r.run(s));
		Automaton p2=new RegExp(rp,RegExp.ALL).toAutomaton();
		RunAutomaton r2= new RunAutomaton(p2);
		System.out.println("from second: "+ r2+"\n"+r2.run(s));
		Automaton diff=BasicOperations.minus(p, p2);
		RunAutomaton rd= new RunAutomaton(diff);
		System.out.println("difference: "+rd);
		System.out.println(diff.run(s));
		
	}
	/*
	 * Separates test strings accepted by implementation and documentation separately
	 */
	static Tuple compliancewith(ArrayList<String> teststr,String codereg,String specreg, RunAutomaton rex)
	{
		ArrayList<String> code=new ArrayList<String>();
		ArrayList<String> doc=new ArrayList<String>();
		Tuple<ArrayList<String>,ArrayList<String>> separatedstr=new Tuple(code,doc);
		Automaton c=new RegExp(codereg,RegExp.ALL).toAutomaton();
		RunAutomaton rc= new RunAutomaton(c);
		Automaton s=new RegExp(specreg,RegExp.ALL).toAutomaton();
		RunAutomaton rs= new RunAutomaton(s);
		LinkedHashSet<String> teststr_set=new LinkedHashSet<String>(teststr);
		int ctr=1;
		for(String str:teststr_set)
		{
			if(rc.run(str) && !rs.run(str))
				{
				if(ctr%2==1)
					code.add(str);
				}
			else if(rs.run(str) && !rc.run(str))
				{
				if(ctr%2==1)
					doc.add(str);
				}
			else if(!rc.run(str) && !rs.run(str) && !rex.run(str))
				System.out.println("-->"+str);
		ctr++;
		}
		System.out.println("**TESTSTRINGS complying with specifications");
		for(String st: (doc))
				System.out.println(st);
		
		System.out.println("**TESTSTRINGS complying with code");
		for(String st: (code))
				System.out.println(st);
		System.out.println("\nTotal strings:"+doc.size()+"+"+code.size()+"\n");
		return separatedstr;
	}
	
	
	static Tuple compliancewith(HashSet<String> teststr,String codereg,String specreg, RunAutomaton rex,String[] spl)
	{
		ArrayList<String> code=new ArrayList<String>();
		ArrayList<String> doc=new ArrayList<String>();
		Tuple<ArrayList<String>,ArrayList<String>> separatedstr=new Tuple(code,doc);
		Automaton c=new RegExp(codereg,RegExp.ALL).toAutomaton();
		RunAutomaton rc= new RunAutomaton(c);
		Automaton s=new RegExp(specreg,RegExp.ALL).toAutomaton();
		RunAutomaton rs= new RunAutomaton(s);
		String tmp="";
		LinkedHashSet<String> teststr_set=new LinkedHashSet<String>(teststr);
		int ctr=1;
		for(String str:teststr_set)
		{	for(String sp:spl)
			{
			if(rc.run(str) && !rs.run(str))
				{tmp=str.replace("`", sp);
				if(!code.contains(tmp) && !doc.contains(tmp) && ctr%2==1)
					code.add(tmp);
				}
			else if(rs.run(str) && !rc.run(str))
				{
				tmp=str.replace("`", sp);
				if(!code.contains(tmp) && !doc.contains(tmp) && ctr%2==1)
					doc.add(tmp);
				}
			else if(!rc.run(str) && !rs.run(str) && !rex.run(str))
				System.out.println("-->"+str);
		ctr++;
			}
		}
		System.out.println("**TESTSTRINGS complying with specifications");
		for(String st: (doc))
			System.out.println(st);
		
		System.out.println("**TESTSTRINGS complying with code");
		for(String st: (code))//hashcode on String is deterministic, order of insertion varies minimally
			System.out.println(st);
		
		System.out.println("\nTotal Strings:"+doc.size()+"+"+code.size()+"\n");
		return separatedstr;
	}
	
	static String getsplchar(HashSet<Character> specialchar)
	{
		String splchar="";
		for(char c:specialchar)
		{
			if(c=='\u0000')
				continue;
			if(MapRegex.needescapechars.contains(Character.toString(c)))
				splchar=splchar.concat("\\"+Character.toString(c));
			else
				splchar=splchar.concat(Character.toString(c));
		}
		if(splchar.length()>0)
			splchar="["+splchar+"]";
		else
			splchar="()";
	//	System.out.println(splchar);
		return splchar;
	}
	
	/**Take the regex from spec and code and
	 * returns spl char of spec that are not
	 * present in codereg
	 **/
	static HashSet<Character> getdistinctspec(String specreg,String codereg)
	{
		HashSet<Character> spec=new LinkedHashSet();
		for(char c:specreg.toCharArray())
		{
			spec.add(c);
		}
		HashSet<Character> code=new LinkedHashSet();
		for(char c:codereg.toCharArray())
		{
			code.add(c);
		}
		spec.removeAll(code);//Take set difference
		String sc;
		HashSet<Character> h=(HashSet<Character>) spec.clone();
		for(char c: h)
		{	sc=Character.toString(c);
			if(MapRegex.needescapechars.contains(sc))
			{
				if(!specreg.contains("\\"+sc))
				{
					spec.remove(c);
				}
			}
			if((c>=48 && c<=57)||(c>=65 && c<=90)||(c>=97 && c<=122))//ignore alphanumeric
				spec.remove(c);
		}
		return spec;
		
	}
	void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
