package DeriveRegex;

import org.apache.commons.text.StringEscapeUtils;

public class TestJSONEscape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//TEXT-118
		String backspaceString = "Backspace: \b";
		//String deleteString = "Delete: \u007F";
		  //String deleteString = "{\",z1\\fA\"\":\"Ar9\\/\"\",\"g\\fA4\"\"}";
		String old="{\"1\":\"\"\",\"S8,Bv\\\"\"}";
		  String deleteString = "{\"\\/3,Z\":\"\"}";
		  String s2="{\"0\"\":\"vL\"\",\"N,\\7p\"}";
		  String s3="{maggie:\"d	j\"}";
		  String s4="{\" \"\":\" \"\"}";
		 // System.out.println(StringEscapeUtils.escapeJson(backspaceString));//works correct
		  System.out.println(StringEscapeUtils.escapeJson(s4));//fails, should give \\u007F
	}

}
