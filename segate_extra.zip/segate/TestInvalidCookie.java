package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.google.common.io.Files;

import okhttp3.Cookie;
import okhttp3.HttpUrl;

public class TestInvalidCookie {

	//okhttp-2939 Invalid character in cookie
	//Note: running static analyzer takes long on dateCharacterOffset method(fixpoint not reached?)
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HttpUrl url = HttpUrl.parse("https://example.com/");
		Cookie cookie = Cookie.parse(url, "SID=31d4d96e407aad4\u008f2");//should trim the non-ascii char
		System.out.println(cookie);
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		HttpUrl url = HttpUrl.parse("https://example.com/");
		
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				writeToFile(fname,s+"\t-->\t"+Cookie.parse(url, s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
