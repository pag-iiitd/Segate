package DeriveRegex;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.util.HashSet;
import java.util.Iterator;

import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.HttpUrl.Builder;
import okhttp3.JavaNetCookieJar;
import static java.net.CookiePolicy.ACCEPT_ORIGINAL_SERVER;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
public class TestMultiCookies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//okhttp-2202
		String str="Set-Cookie: auth=secretStuff; session=myFrontendSession";
		String str2="44=44; Comment=SD4M4P4VDDMDPDVMMPMVPPVVeDoMaPath4";
		//HttpCookie h = new HttpCookie("name1","value1");
		//System.out.println(h.parse(str));
		//System.out.println(h.parse("donald=duck; mickey=mouse; version=x"));
		// CookieManager cookieManager = new CookieManager(null, null);
		JavaNetCookieJar c=new JavaNetCookieJar(new CookieManager(null,ACCEPT_ORIGINAL_SERVER));
		//To be uncommented only for verification purpose
	/*		HttpUrl url=new HttpUrl.Builder()
			       .scheme("https")
			       .host("www.google.com")
			       .addPathSegment("search")
			       .addQueryParameter("q", "polar bears")
			       .build();

		c.decodeHeaderAsJavaNetCookies(url, str2);
	*/	
		c.decodeHeaderAsJavaNetCookies(null, str2);
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		JavaNetCookieJar c=new JavaNetCookieJar(new CookieManager(null,ACCEPT_ORIGINAL_SERVER));
		HttpUrl url=new HttpUrl.Builder()
			       .scheme("https")
			       .host("www.google.com")
			       .addPathSegment("search")
			       .addQueryParameter("q", "polar bears")
			       .build();

		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				writeToFile(fname,s+"\t-->\t"+c.decodeHeaderAsJavaNetCookies(url, s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
