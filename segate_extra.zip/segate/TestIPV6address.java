package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;

import com.google.common.net.InetAddresses;

public class TestIPV6address {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Guava-1557
		System.out.println(InetAddresses.isInetAddress("fe80:0:0:0:c1e1:54cf:68bc:9d5e"));
		//System.out.println(InetAddresses.forString("0000:0000::00004"));//new bug explored
		//System.out.println(InetAddresses.isInetAddress("c4::%40"));
		//System.out.println(InetAddresses.isInetAddress("2001:db8::/32"));//should give true
		//System.out.println(InetAddresses.isInetAddress("fe80:0:0:0:c1e1:54cf:68bc:9d5e%25a"));//should give true
		//System.out.println(InetAddresses.isInetAddress("804C:404C::0:cC:C0:00C1c"));//unknown bug- should give false but gives true; or C0c0:Cc00:c4cc::04C00 may be 0 trimming
		//subnet not handled
		//System.out.println(InetAddresses.isInetAddress("e000:0000:0000:0000:0000::00004"));//unknown bug- should give false but gives true; //subnet not handled
		
		//System.out.println(InetAddresses.isInetAddress("fe80::aaaaaa"));//buggy, format exception should be thrown
		//System.out.println(InetAddresses.isInetAddress("::FFFF:12.155.166.101"));//ipv4 mapped ipv6
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+InetAddresses.isInetAddress(s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
