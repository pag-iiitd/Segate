package DeriveRegex;
import org.asynchttpclient.uri.*;
public class TestUriAnchor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//async-http-client-1455
		 Uri context = new Uri("", null, "", 80, "", "");
	     String originalUrl= "http://mangoroot.in#animal@lele.com/b?q";
	String originalUrl2="jk://sfh#!k=Zfohlzrq_$-u.;~nia4@mg'OU%C/Ct?";
	UriParser parser=new UriParser();
        parser.parse(context, originalUrl2);
        System.out.println(parser.host);
	}

}
