package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.codec.Base64;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;
import org.springframework.boot.test.EnvironmentTestUtils;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.StandardEnvironment;

public class TestEnvirPair {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Spring-boot3273
		ConfigurableEnvironment environment = new StandardEnvironment();
		EnvironmentTestUtils.addEnvironment("tests", environment, "+5+=55+:");
		/**
		 * failed case of misinterpretation
		 *  if separator is = and name contains colon
		 *  Expected: name as my:foo and value as bar2
		 *  Actual: name as my and value as foo-bar2
		 */
		//? case of double colon when colon part of name?
		int i;
		/*for(i=0;i<args.length;i++)
		{
		try{
			System.out.println(args[i]);
			EnvironmentTestUtils.addEnvironment("tests", environment, args[i]);
			}
		catch(Exception e)
			{
			System.out.println(e.toString());
			}
		}	
*/		//EnvironmentTestUtils.addEnvironment("tests", environment, "5Ss=::S");
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		ConfigurableEnvironment environment = new StandardEnvironment();
		
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+EnvironmentTestUtils.addEnvironment_d("tests", environment, s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
