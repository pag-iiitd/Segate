package DeriveRegex;

import java.net.MalformedURLException;
import java.net.URL;

import gumi.builders.UrlBuilder;

public class Test_URLbuilder5 {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		System.out.println(UrlBuilder.fromString("http://somehost.com/page/++++"));
	}

}
