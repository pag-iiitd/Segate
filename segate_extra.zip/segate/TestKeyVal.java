package DeriveRegex;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.boot.builder.SpringApplicationBuilder;

import com.icegreen.greenmail.junit.GreenMailRule;
import com.icegreen.greenmail.server.AbstractServer;
import com.icegreen.greenmail.util.GreenMailUtil;
import com.icegreen.greenmail.util.Retriever;
import com.icegreen.greenmail.util.ServerSetupTest;

public class TestKeyVal {
	public static void main(String[] args){
		 //Map<String, Object> pairs = new SpringApplicationBuilder().getMapFromKeyValuePairs2("logging.path=c:\\logging.file");
		//Spring-6121
		Map<String, Object> pairs2 = new SpringApplicationBuilder().getMapFromKeyValuePairs2("++/=+/:==");
		 
		 System.out.println(pairs2);
	}
}
