package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.google.common.io.Files;

import okhttp3.Headers.Builder;

public class TestHeaderSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//okhttp 2842
		Builder b=new Builder();
		b.add("~ q 2:q ");//space in key is invalid as per rfc7230 3.2
		//b.add("'O *q:");
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{Builder b=new Builder();
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				writeToFile(fname,s+"\t-->\t"+b.add_(s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
