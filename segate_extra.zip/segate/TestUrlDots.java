package DeriveRegex;

import org.asynchttpclient.uri.Uri;

public class TestUrlDots {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//async-http-client-1071
		Uri context = Uri.create3(null,"https://graph.facebook.com/abc/");
		Uri url = Uri.create3(context, "/./f+larto_org.4Ok@l?i.=r-#h/b.");
		System.out.println(url.getPath());
		//Uri url2 = Uri.create(context, "/./f+larto_org.4Ok@l?i.=r-#h/b.");
		//System.out.println(url2.getPath());
	}

}
