package DeriveRegex;

import org.apache.commons.validator.routines.InetAddressValidator;

public class TestValidIPV6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//VALIDATOR-419
System.out.println(new InetAddressValidator().isValidInet6Address("0::ffff:192.168.1.1:192.168.1.1"));
	// System.out.println(new InetAddressValidator().isValidInet6Address("0CC::%CC0"));//should give true


	}

}
