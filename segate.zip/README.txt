segate.zip contains the following:
1) "bin" folder containing
	i) bytecode of the SEGATE tool, bundled along with a faulty method from our dataset to generate strings for.
	ii) The necessary jars needed to the run the implementation (except the soot jar that is required to be downloaded separately).
The bytecode of the following files have been included in the bin folder. We are sharing the source code only for understanding purpose.
3) TestGenerateStrings.java with a sample test using different components of SEGATE.
4) TestFileExtension.java containing the program invoking the faulty method getFileExtension to test. 
*****************

Requires: Java 8 on the system

*****************
The tool is expected to generate test inputs to test the getFileExtension method which has been discussed in the Motivating Example section of the paper.

Execution steps:
1) Dependency- Download the jar for soot avaiable here: https://soot-build.cs.uni-paderborn.de/public/origin/master/soot/soot-master/3.1.0/build/sootclasses-trunk-jar-with-dependencies.jar
2) Unzip segate.zip to extract the files.
3) Move the soot jar to the bin folder in the extracted "segate" directory.
4) Open the command prompt and change the directory to the "segate" directory
5) Execute the following command: 
	For Linux: java -cp bin:bin/*:. StringGenerator.TestGenerateStrings
	For Windows: java -cp bin;bin/*;. StringGenerator.TestGenerateStrings
*****************

Output Description:

The output is expected to show the working of Soot showing derivation of regular expression(r_impl) from the program through static analysis.
The regular expression (r_spec) passed to the Test Generator Component would show the sample test strings getting generated. One of the generated test strings "S:\44 44-.--\" reveals the defect for the method under test as discussed in the paper.
The r_spec has been derived from the documentation and already included as input to the tool.