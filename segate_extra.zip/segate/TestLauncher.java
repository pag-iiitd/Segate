package DeriveRegex;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import org.springframework.boot.loader.PropertiesLauncher;

import okhttp3.Cookie;

public class TestLauncher {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//Spring-boot-12325
		File f=new File("ss S4S/black.jar");
		System.setProperty("loader.path",f.toURI().toURL().toString());
		PropertiesLauncher p=new PropertiesLauncher();
		System.getProperty("user.dir");
		p.getClassPathArchives("");
		//System.out.println(p.getClassPathArchives());//TO enable only for verification
	}

	public static void testall(String fname,HashSet<String> teststr)
	{PropertiesLauncher p=new PropertiesLauncher();
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				File f=new File(s);
				System.setProperty("loader.path",f.toURI().toURL().toString());
				writeToFile(fname,s+"\t-->\t"+p.getClassPathArchives()+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
