package DeriveRegex;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.apache.commons.lang3.builder.ToStringStyle.JsonToStringStyle;

public class TestJsonArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//lang-1374
			Integer base = Integer.valueOf(5);
			
			(new JsonToStringStyle()).isJsonArray("[-44,{\"\t\":44E+4},\"\",4e-44,[4e-4,-4]]");
               
	}

}
