package StringGenerator;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

import dk.brics.automaton.Automaton;
import dk.brics.automaton.AutomatonMatcher;
import dk.brics.automaton.BasicOperations;
import dk.brics.automaton.MinimizationOperations;
import dk.brics.automaton.RegExp;
import dk.brics.automaton.RunAutomaton;
import dk.brics.automaton.SpecialOperations;
import dk.brics.automaton.State;
import dk.brics.automaton.StatePair;
import dk.brics.automaton.Transition;
import DeriveRegex.*;

public class TestGenerateStrings {
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		Runtime runtime = Runtime.getRuntime();
	    long usedMemoryBefore = runtime.totalMemory() - runtime.freeMemory();
	    System.out.println("Used Memory before" + usedMemoryBefore);
	    long startTime = System.currentTimeMillis();
	    //// working code here
	    //test_dircontains(args);//IO499
	    //test_fileext(args);//Guava-1462
		//test_cred(args);//Shiro-375
		//test_IPV6(args); //Guava-1557
		//test_phone(args); //libphonennumber1672
	   //test_envirpair(args);//Springboot-3273
		//test_URLParser(args);//http-client392
		//test_extnAds(args);//IO567
		//test_normalize(args);//IO559
		//test_fullpath(args);//IO545
		//test_dropcookie(args);//okhttp-2549
		//test_multicookie(args);//okhttp-2202
		//test_launcher(args);//Spring-boot-12325
		//test_jsonparser(args);//Spring-boot 12297 and 11992
		//test_invalidcookie(args);//okhttp-2939
	    //test_invalidheader(args);//okhttp-2842
	    //test_concat(args);//IO-552
		//test_filecolon(args);//IO-483
	    //test_anchorurl(args);//async-http-client-1455
	    //test_urlslash(args);//async-http-client-1110
	    //test_urldot(args);//async-http-client-1071
	    //test_jsonarr(args);//lang-1374
	    //test_headerfield(args);//NET-582
	    //test_uriext(args);//Spring-15786
	    //test_keyval(args);//Spring-6121
	    //test_jsonescape(args);//TEXT-118
	    //test_validurl(args);//VALIDATOR-411,420
	    //test_ValidIPV6(args);//VALIDATOR-419
	    //test_LANG1395(args);
	   // test_urlbuilder5(args);
	   // test_urlbuilder39(args);
	    //test_greenmail213(args);
	    
	    long endTime = System.currentTimeMillis();
	    float duration = (float) ((endTime - startTime)/1000.0);  

		long usedMemoryAfter = runtime.totalMemory() - runtime.freeMemory();
	   // System.out.println("Memory increased:" + ((usedMemoryAfter-usedMemoryBefore)/1000000.0));
	
	    System.out.println("Memory Usage: "+new MemoryUsage().getSettledUsedMemory()/1000000.0);
		System.out.println("Time taken:" + duration);
				
	}
	
	//ORACLE 1//Works
	static void test_dircontains(String[] args) throws Exception
	{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestDirectoryContains";
		
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9_\\-\\.\\\\\\~ ]","[\\~a-zA-Z0-9_\\-\\.\\\\ `]");
		
		String filepath_spec;//="(/top(/[a-zA-Z_\\-0-9\\.]+)+/?)"+"&"+InterProcCFG.charset+"*";
		String digit    = "([0-9])";
	      String upalpha  = "([A-Z])";
	      String lowalpha = "([a-z])";
	      String alpha         = "("+lowalpha+"|"+upalpha+")";
	      String alphanum      = "("+alpha+"|"+digit+")";
	      String hex           = "("+digit+"|[A-Fa-f])";
	      String pct_encoded   = "(%"+hex+hex+")";
	      String mark          = "([\\-_\\~])";//` is for non-special .
	      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ `]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
	      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
	      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
	      String segment         = "("+unreserved+")*";//replaced pchar
	      String segment_nz         = "("+unreserved+")+";//replaced pchar
	      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*)?)";
	    filepath_spec="\\\\top"+path_absolute;
		
		System.out.println("r_spec:"+filepath_spec);
		//String filepath_spec=FetchRegex.getreg("directory")+"&"+InterProcCFG.charset+"*";
		//Enable for blackbox fuzz testing
		//test2(filepath_spec,"", new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		
		//System.out.println(filepath_spec);
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			code_regex=code_regex.replace("`canonicalParent`", "\\\\top");
			
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
			System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			filepath_spec=filepath_spec+"&("+ip.charset+"|"+splchar+")*";
			System.out.println(code_regex);
			HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar);
			//DeriveRegex.TestDirectoryContains.testall((cnt++)+"dir_499"+".txt", teststr);
			}
	}
	
	//ORACLE 2//Works
	static void test_fileext(String[] args) throws Exception
	{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestFileExtension";
		String validchar="[a-zA-Z0-9\\-\\\\_\\.\\~:\\|/ ]";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\-_\\.\\~\\\\ ]",validchar);//cannot allow some spl char to occur anywhere, hence not including in charset
		String filepath_spec;//="(([a-zA-Z]:)|\\\\\\\\)?(\\\\[a-zA-Z_\\-0-9]+\\.?[a-zA-Z_\\-0-9]+)+(\\\\?|(:([a-zA-Z0-9]+[_\\-\\.]?[a-zA-Z0-9]+)+)?)";
		String digit    = "([0-9])";
	      String upalpha  = "([A-Z])";
	      String lowalpha = "([a-z])";
	      String alpha         = "("+lowalpha+"|"+upalpha+")";
	      String alphanum      = "("+alpha+"|"+digit+")";
	      String hex           = "("+digit+"|[A-Fa-f])";
	      String pct_encoded   = "(%"+hex+hex+")";
	      String mark          = "([\\-_\\~])";//` is for non-special .
	      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ `]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
	      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
	      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
	      String segment         = "("+unreserved+")*";//replaced pchar
	      String segment_nz         = "("+unreserved+")+";//replaced pchar
	      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(`))+)?)?)";
	      String relativepath="("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(`))+)?)";
	     String drivemarker= "([:\\|])";
	     String driveletter="("+alpha+"("+drivemarker+")?)";
	     String path_abs_win="("+driveletter+path_absolute+")";
	     String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+")(\\#("+unreserved+")+)?)";//# to denote spl case of : as ads separator
		filepath_spec=localfile;
		String[] spl={"."};
		
		System.out.println("r_spec:"+filepath_spec);
		//String filepath_spec=FetchRegex.getreg("file path");
		//Enable for blackbox fuzz testing
		//test2(filepath_spec,"", new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		//System.out.println(filepath_spec);
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			filepath_spec=filepath_spec+"&("+ip.charset+"|"+splchar+")*";
			//System.out.println(code_regex);
			HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar,spl);
			//DeriveRegex.TestFileExtension.testall((cnt++)+"Fext_1462"+".txt", teststr);
			}
	}
	
	//ORACLE 3
	static void test_IPV6(String[] args) throws Exception
	{//charset:[0-9A-Fa-f:\\.]
		String sample="DeriveRegex.TestIPV6address";
		//Code inferred regex
		String validchar="[0-9A-Fa-f:\\.%]";
		InterProcCFG ip=new InterProcCFG("[0-9A-Fa-f:\\.]",validchar);
		String ip_specv4="((([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])))";
		String ip_specv6="((((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))))([%][0-9A-Fa-f]+)?)";
		String ipv="("+ip_specv4+"|"+ip_specv6+")";
		System.out.println("r_spec:"+ipv);
		//String ipv=FetchRegex.getreg("ip address");
		//Enable for blackbox fuzz testing
		//test2(ipv,"", new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		System.out.println(ipv);
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(ipv,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			ipv=ipv+"&("+ip.charset+"|[%]"+"|"+splchar+")*";
			//System.out.println(code_regex);
			HashSet<String> teststr=test(ipv,code_regex,totalsplchar);
			//DeriveRegex.TestIPV6address.testall((cnt++)+"ipv6_1557"+".txt", teststr);
			}
	}
	
	//ORACLE 4//Works
	static void test_cred(String[] args) throws Exception
	{//charset: [a-zA-Z0-9/:\\+]
		String sample="DeriveRegex.TestCredentials";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9/`\\+]","[a-zA-Z0-9/:\\+`]");
		String usrpss_spec="([a-zA-Z0-9\\+/]+(:)[a-zA-Z0-9`\\+/]+)";//` indicates : as non seperator
		System.out.println("r_spec:"+usrpss_spec);
		
		//String usrpss_spec=FetchRegex.getreg("username password pair in header");
		String[] spl={":"};
		//Enable for blackbox fuzz testing
		//test2(usrpss_spec,"", new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		//System.out.println(usrpss_spec);
		int cnt=0;
		while(rIt.hasNext())
			{String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(usrpss_spec,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			usrpss_spec=usrpss_spec+"&("+ip.charset+"|"+splchar+")*";
			//System.out.println(code_regex);
			HashSet<String> teststr=test(usrpss_spec,code_regex,totalsplchar,spl);
			//DeriveRegex.TestCredentials.testall((cnt++)+"cred_375"+".txt", teststr);
			}
	}

	//ORACLE 5
	static void test_phone(String[] args) throws Exception
		{//charset: [a-zA-Z0-9/\\+\\-#\\\\]
			String sample="DeriveRegex.TestPhoneNumber";
			String validchar="[a-zA-Z0-9\\\\;/\\.=#'\\(\\)\\+\\$\\?:@\\&\\~_!\\-\\* ]";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9/\\+\\-#\\\\ ]",validchar);
			String reserved="([;/\\?:@\\&=\\+\\$,])";
			String visualsep="([\\-\\.\\(\\)\u0020\u0009])";
			String alphanum="([a-zA-Z0-9])";
			String phonedighex="([0-9A-F\\*#]|"+visualsep+")";
			String phonedig="([0-9]|"+visualsep+")";
			String paramunreserved="([\\[\\]/:\\&\\+\\$])";
			String pctenc="(%[0-9A-F][0-9A-F])";
			String mark="([\\-_\\.!\\~\\*'\\(\\)])";
			String unreserved="("+alphanum+"|"+mark+")";
			String uric="("+reserved+"|"+unreserved+"|"+pctenc+")";
			String paramchar="("+paramunreserved+"|"+unreserved+"|"+pctenc+")";
			String pvalue="("+paramchar+"+)";
			String pname="(("+alphanum+"|"+"\\-"+")+)";
			String parameter="(;"+pname+"(="+pvalue+")?)";
			String toplabel="([A-Za-z]|([A-Za-z](\\-|"+alphanum+")*"+alphanum+")"+")";
			String domainlabel="("+alphanum+"|("+alphanum+"(\\-|"+alphanum+")*"+alphanum+")"+")";
			String domainname="(("+domainlabel+"\\.)*"+toplabel+"\\.?)";
			String localnumdig="(("+phonedighex+")*([0-9A-F\\*#])("+phonedighex+")*)";
			String globalnumdig="(\\+("+phonedig+")*[0-9]("+phonedig+")*)";
			String desc="("+domainname+"|"+globalnumdig+")";
			String context="(;phone\\-context="+desc+")";
			String ext="(;ext=("+phonedig+")+)";
			String isdnsub="(;isub=("+uric+")+)";
			String par="("+parameter+"|"+ext+"|"+isdnsub+")";
			String localnum="("+localnumdig+"("+par+")*"+context+"("+par+")*)";
			String globalnum="("+globalnumdig+"("+par+")*)";
			String telsub="("+globalnum+"|"+localnum+")";
			String teluri="((tel:)?"+telsub+")";
			
			String usrpss_spec=teluri;
			System.out.println("r_spec:"+usrpss_spec);
			//String usrpss_spec=FetchRegex.getreg("phone number");
			//Enable for blackbox fuzz testing
			//test2(usrpss_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(usrpss_spec);
			int cnt=0;
			while(rIt.hasNext())
				{
				String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(usrpss_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+validchar+"|"+splchar+")*";
				usrpss_spec=usrpss_spec+"&("+validchar+"|"+splchar+")*";
				HashSet<String> teststr=test(usrpss_spec,code_regex,totalsplchar);
				//DeriveRegex.TestPhoneNumber.testall((cnt++)+"phn_1672"+".txt", teststr);
				}
		}
	
	//ORACLE 6
		static void test_envirpair(String[] args) throws Exception
			{//charset: [a-zA-Z0-9/\\+=:]
				String sample="DeriveRegex.TestEnvirPair";
				InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9/\\+=:]","[a-zA-Z0-9/\\+=:`]");
				String[] spl={"=",":"};
				String usrpss_spec="([a-zA-Z0-9/\\+]+[`][a-zA-Z0-9/\\+:=]+)";////treat` as special char denoting [:=] as we need a way to differentiate between the separator char and non sep char
				System.out.println("r_spec:"+usrpss_spec);
				//String usrpss_spec=FetchRegex.getreg("name value pair");
				
				//System.out.println("Testing "+sample);
				//Enable for blackbox fuzz testing
				//test2(usrpss_spec,"", new LinkedHashSet());
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				//System.out.println(usrpss_spec);
				int cnt=0;
				while(rIt.hasNext())
					{
					String code_regex=rIt.next();
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					totalsplchar.addAll(getdistinctspec(usrpss_spec,code_regex));
					//System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
					usrpss_spec=usrpss_spec+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(usrpss_spec,code_regex,totalsplchar,spl);
					//DeriveRegex.TestEnvirPair.testall((cnt++)+"envpair_3273"+".txt", teststr);
					}
			}
	
		//ORACLE 7
		static void test_URLParser(String[] args) throws Exception
		{//charset: [a-zA-Z0-9\\=\\&\\+]
			String sample="DeriveRegex.TestURLParser";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\+]","[a-zA-Z0-9\\+]");
			String usrpss_spec="((([a-zA-Z0-9\\+]|(%[0-9][A-F0-9]))*=([a-zA-Z0-9\\+\\=]|(%[0-9][A-F0-9]))*)(\\&([a-zA-Z0-9\\+]|(%[0-9][A-F0-9]))*=([a-zA-Z0-9\\+\\=]|(%[0-9][A-F0-9]))*)*)";
			System.out.println("r_spec:"+usrpss_spec);
			//String usrpss_spec=FetchRegex.getreg("data key name value pairs");
			
			//System.out.println("Testing "+sample);
			//Enable for blackbox fuzz testing
			//test2(usrpss_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//Manually inferred
			//String codereg="(([a-zA-Z0-9]*(:)[a-zA-Z0-9]*)|([a-zA-Z0-9]*(=)[a-zA-Z0-9]*))"+"&("+ip.charset+"|"+splchar+")*";
			//System.out.println(usrpss_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(usrpss_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				usrpss_spec=usrpss_spec+"&("+ip.charset+"|"+splchar+")*";
				//System.out.println(code_regex);
				HashSet<String> teststr=test(usrpss_spec,code_regex,totalsplchar);
				//DeriveRegex.TestURLParser.testall((cnt++)+"url_392"+".txt", teststr);
				}
			}

		//ORACLE 8
		static void test_extnAds(String[] args) throws Exception
		{//charset: [a-zA-Z0-9\\-\\.\\\\]
			String sample="DeriveRegex.TestADS";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\-\\\\\\._\\:]","[a-zA-Z0-9\\-\\.\\\\_`\\:\\#]");
			String filepath_spec;//="(([a-zA-Z]:)|\\\\\\\\)?(\\\\[a-zA-Z_\\-0-9]+\\.?[a-zA-Z_\\-0-9]+)+(\\\\?|(`([a-zA-Z0-9]+([_\\-\\.]?[a-zA-Z0-9]+)?)+)?)";
			String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphanum      = "("+alpha+"|"+digit+")";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String pct_encoded   = "(%"+hex+hex+")";
		      String mark          = "([\\-_\\~])";//# is for non-special .
		      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ \\.]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
		      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
		      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
		      String segment         = "("+unreserved+")*";//replaced pchar
		      String segment_nz         = "("+unreserved+")+";//replaced pchar
		      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(\\#))+)?)?)";
		      String relativepath="("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.?("+unreserved+"&~(\\#))+)?)";
		     String drivemarker= "([:\\|])";
		     String driveletter="("+alpha+"("+drivemarker+")?)";
		     String path_abs_win="("+driveletter+path_absolute+")";
		     String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+")(\\`("+unreserved+")+)?)";//` to denote spl case of : as ads separator
			filepath_spec=localfile;
			
			System.out.println("r_spec:"+filepath_spec);
			String[] spl={":"};
			//String filepath_spec=FetchRegex.getreg("file path");
			//Enable for blackbox fuzz testing
			//test2(filepath_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(filepath_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				filepath_spec=filepath_spec+"&("+ip.charset+"|:|"+splchar+")*";
				HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar,spl);
				//DeriveRegex.TestADS.testall((cnt++)+"ADS_567"+".txt", teststr);
				}
		}
		
		//ORACLE 9
		static void test_normalize(String[] args) throws Exception
		{//charset: [a-zA-Z0-9\\-\\.\\\\]
			String sample="DeriveRegex.TestNormalize";
			//Code inferred regex
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\-\\.\\\\]","[a-zA-Z0-9\\-\\.\\\\]");
			String filepath_spec="(([a-zA-Z]:)|\\\\\\\\\\.?\\.?)?(\\\\\\.?\\.?[a-zA-Z_\\-0-9\\.]+)+(\\\\?|(:([a-zA-Z0-9]*[_\\-\\.]?)+)?)"+"&"+InterProcCFG.charset+"*";
			System.out.println("r_spec:"+filepath_spec);
			//String filepath_spec=FetchRegex.getreg("file path");
			
			//Enable for blackbox fuzz testingtest2(filepath_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(filepath_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.add('.');
				totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				filepath_spec=filepath_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar);
			//	DeriveRegex.TestNormalize.testall((cnt++)+"norm_559"+".txt", teststr);
				}
		
		}

		
		//ORACLE 10
		static void test_fullpath(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestFullPath";
			//IO-545
			//Testing for Windows
			String validchar="[a-zA-Z0-9_\\~\\-\\.\\\\:\\`]";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9_\\-\\.]",validchar);
			String filepath_spec;//="((([A-Z]:)|\\\\\\\\)?([a-zA-Z_\\-0-9\\.\\~]*(\\\\[a-zA-Z_\\-0-9\\.\\~]+)*)\\\\?)";
			
			String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphanum      = "("+alpha+"|"+digit+")";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String pct_encoded   = "(%"+hex+hex+")";
		      String mark          = "([\\-_\\~])";
		      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ \\.]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
		      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
		      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
		      String segment         = "("+unreserved+")*";//replaced pchar
		      String segment_nz         = "("+unreserved+")+";//replaced pchar
		      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*)?)";
		      String relativepath="("+segment_nz+"(\\\\"+segment+")*)";
		     String drivemarker= "([:\\|])";
		     String driveletter="("+alpha+"("+drivemarker+")?)";
		     String path_abs_win="("+driveletter+path_absolute+")";
		     String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+")(\\`("+unreserved+")+)?)";//` to denote spl case of : as ads separator
			filepath_spec=localfile;
			String[] spl={":"};
			//Enable for blackbox fuzz testing
			//test2(filepath_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			System.out.println("r_spec:"+filepath_spec);
			//String filepath_spec=FetchRegex.getreg("windows or linux file name");
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+validchar+"|"+splchar+")*";
				filepath_spec=filepath_spec+"&("+validchar+"|"+splchar+")*";
				HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar,spl);
				//DeriveRegex.TestFullPath.testall((cnt++)+"fullpth_545"+".txt", teststr);
				ip.specialchar.clear();
				}
		}

		//ORACLE 11
		static void test_dropcookie(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			//okhttp-2549
			String sample="DeriveRegex.TestDropCookie";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\-]","[a-zA-Z0-9\\-\\.\\\\:]");
			String ip_specv4="((([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5])\\.([01]?[0-9][0-9]?|2[0-4][0-9]|25[0-5]))(/[0-9]+)?)";
			String ip_specv6="((((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))))([%/][0-9A-Fa-f]+)?)";
			String usr_spec="("+ip_specv4+"|"+ip_specv6+"|"+"((([0-9A-Za-z\\-]+(\\.)[0-9A-Za-z\\-]+)*))"+")";//as per rfc1035
			System.out.println("r_spec:"+usr_spec);
			//String usr_spec=FetchRegex.getreg("domain name");
			
			int size=0;
			//Enable for blackbox fuzz testing
			//test2(usr_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(usr_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				//totalsplchar.addAll(getdistinctspec(usr_spec,code_regex));
			//	System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				usr_spec=usr_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(usr_spec,code_regex,ip.specialchar);
				//DeriveRegex.TestDropCookie.testall((cnt++)+"dropcook_2549"+".txt", teststr);
				}
			}
	
		//ORACLE 12
		static void test_multicookie(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestMultiCookies";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9]","[a-zA-Z0-9\\-=;: ]");
			String usr_spec="(((Set\\-Cookie:)|(Set\\-Cookie2:))?(\u0020)?[A-Za-z0-9]+=[A-Za-z0-9]+(;\u0020([A-Za-z0-9]+=[A-Za-z0-9]+)|(Comment=[A-Za-z0-9]+)|(Domain=[A-Za-z0-9]+)|(Max\\-age=[A-Za-z0-9]+)|(Path=[A-Za-z0-9]+)|(Secure)|(Version=[0-9]+))*)";
			System.out.println("r_spec:"+usr_spec);
			//String usr_spec=FetchRegex.getreg("request header");
			//Enable for blackbox fuzz testing
			//test2(usr_spec,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.add(';');
				
				totalsplchar.addAll(getdistinctspec(usr_spec,code_regex));
				
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);///change to validchar below
				code_regex=code_regex+"&("+ip.validchar+"|"+splchar+")*";
				usr_spec=usr_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(usr_spec,code_regex,totalsplchar);//DeriveRegex.TestMultiCookies.testall((cnt++)+"multcook_2202"+".txt", teststr);
				}
			}

		//ORACLE 13
	static void test_launcher(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestLauncher";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\.\\\\\\*\\-:\\-_\\+ ]","[a-zA-Z0-9\\.\\\\\\*\\-:_\\-\\+ ]");
		String filepath_spec;//="((([a-zA-Z]+:)|(\\./))?([a-zA-Z0-9\\-_\\+]+[\\.]*[ ]*[a-zA-Z0-9\\-_\\+]+/)+([a-zA-Z0-9\\-_\\+]+[\\.]*[ ]*[a-zA-Z0-9\\-_\\+]+)((\\.zip)|(\\.jar)|/)?)";//has space separate as cannot have space at beginning or end of a component name
		String digit    = "([0-9])";
	      String upalpha  = "([A-Z])";
	      String lowalpha = "([a-z])";
	      String alpha         = "("+lowalpha+"|"+upalpha+")";
	      String alphanum      = "("+alpha+"|"+digit+")";
	      String hex           = "("+digit+"|[A-Fa-f])";
	      String pct_encoded   = "(%"+hex+hex+")";
	      String mark          = "([\\-_\\~])";//# is for non-special .
	      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ \\.]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
	      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
	      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
	      String segment         = "("+unreserved+")*";//replaced pchar
	      String segment_nz         = "("+unreserved+")+";//replaced pchar
	      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.(`))?)?)";
	      String relativepath="("+segment_nz+"(\\\\"+segment+")*(\\\\("+unreserved+")+\\.(`))?)";
	     String drivemarker= "([:\\|])";
	     String driveletter="("+alpha+"("+drivemarker+")?)";
	     String path_abs_win="("+driveletter+path_absolute+")";
	     String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+"))";
		filepath_spec=localfile;
		
		String[] spl={"zip","jar"};
		System.out.println("r_spec:"+filepath_spec);
		//String filepath_spec=FetchRegex.getreg("class path");
		//Enable for blackbox fuzz testing
		//test2(filepath_spec,"", new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			filepath_spec=filepath_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar,spl);//remove special characters to avoid overhead
			//DeriveRegex.TestLauncher.testall((cnt++)+"launch_12325"+".txt", teststr);
			}
		}
	
	//ORACLE 14,15- two bugs covered in single method
	static void test_jsonparser(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestJsonparser";
		//Spring-boot 12297 and 11992		
		String validchar="[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ ]";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ `]",validchar);
		//for one level of nesting
		String string="((\\\"\\\")|(\\\"([a-zA-Z0-9`]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r)+\\\"))";
		String number="(\\-?[0-9]+(\\.[0-9]+)?([eE][\\+\\-][0-9]+)?)";
		String element="("+string+"|"+number+"|(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))";
		String array="((\\[\\])|(\\["+element+"(,"+element+")*]))";//(,"+string+"|"+number+"|"+"(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\["+string+"|"+number+"\\]))*\\]"+"))";
		String pair="("+string+":"+"("+string+"|"+number+"|"+array+"|null|true|false|"+"(\\{"+string+":"+"("+string+"|"+number+"|"+array+"|null|true|false"+")\\})"+"))";
		String pairs="("+pair+"(,"+pair+")*)";
		String json_spec_adv="((\\{\\})|(\\{"+pairs+"\\}))";//"\\{.*\\:\\{.*\\:.*\\}\\}";
	
		String pairb="("+string+":"+"("+string+"))";
		String pairsb="("+pairb+"(,"+pairb+")*)";
		String json_spec="((\\{\\})|(\\{"+pairsb+"\\}))";	
		//System.out.println(json_spec1);
		//String json_spec=FetchRegex.getreg("json");
		//Enable for blackbox fuzz testing
		//test2(json_spec,"",new LinkedHashSet());
		String[] spl={","};
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			//totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
		//	System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+validchar+")*";
			json_spec=json_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(json_spec,code_regex,totalsplchar,spl);//remove special characters to avoid overhead
		//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
			}
		}
	
	//ORACLE 16
	static void test_invalidcookie(String[] args) throws Exception
	{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestInvalidCookie";
		InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9=:]","[a-zA-Z0-9=:;\\-]");
		String usr_spec="(((Set\\-Cookie:)|(Set\\-Cookie2:))?(\u0020)?[A-Za-z0-9]+=[A-Za-z0-9]+(;\u0020([A-Za-z0-9]+=[A-Za-z0-9]+)|(Comment=[A-Za-z0-9]+)|(Domain=[A-Za-z0-9]+)|(Max\\-age=[A-Za-z0-9]+)|(Path=[A-Za-z0-9]+)|(Secure)|(Version=[0-9]+))*)";
		System.out.println("r_spec:"+usr_spec);
		//String usr_spec=FetchRegex.getreg("http request header");
	
		//Enable for blackbox fuzz testing
		//test2(usr_spec,"",new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		
		int cnt=0;
		while(rIt.hasNext())
			{String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			totalsplchar.addAll(getdistinctspec(usr_spec,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			usr_spec=usr_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(usr_spec,code_regex,totalsplchar);
			//DeriveRegex.TestInvalidCookie.testall((cnt++)+"cookie_2939"+".txt", teststr);
			}
		}
	
	//ORACLE 17
		static void test_invalidheader(String[] args) throws Exception
		{//okhttp 2842
			//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestHeaderSpace";
			String validcharset="([\u0020-\u007e])";
			InterProcCFG ip=new InterProcCFG("[\u0020-\u007e]",validcharset);
			String obsfold="([ \t]+)";
			String fieldvarchar="([\u0021-\u007e]|(%x[8-9A-F][0-9A-F]))";
			String fieldcon="("+fieldvarchar+"("+obsfold+fieldvarchar+")?)";
			String fieldval="("+fieldcon+"|"+obsfold+")*";
			String fieldname="(([!\\#\\$%\\&'\\*\\+\\-\\.\\^_`\\|\\~0-9A-Fa-f])+)";
			String headerfield="("+fieldname+":[ ]?"+fieldval+"[ ]?)";
			
			String usr_spec=headerfield;
			System.out.println("r_spec:"+usr_spec);
			//String usr_spec=FetchRegex.getreg("header field");
			
			//Enable for blackbox fuzz testing
			//test2(usr_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			System.out.println(usr_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(usr_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+validcharset+"|"+splchar+")*";
				usr_spec=usr_spec+"&("+validcharset+"|"+splchar+")*";
				LinkedHashSet s=new LinkedHashSet();
				s.add(':'); s.add(' ');
				HashSet<String> teststr=test(usr_spec,code_regex,totalsplchar);
				//DeriveRegex.TestHeaderSpace.testall((cnt++)+"header_2842"+".txt", teststr);
				}
		}
		
		//ORACLE 18
		static void test_concat(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestConcat";
			//Testing for Windows
			String validchar="[a-zA-Z0-9_\\-\\.\\~:\\\\ ]";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9_\\-\\.\\\\\\~ ]",validchar);
			String filepath_spec;//="((([a-zA-Z]:)|\\\\\\\\)?([a-zA-Z_\\-0-9\\.\\~]*(\\\\[a-zA-Z_\\-0-9\\.\\~]+)*)\\\\?)";
			String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphanum      = "("+alpha+"|"+digit+")";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String pct_encoded   = "(%"+hex+hex+")";
		      String mark          = "([\\-_\\~])";
		      String unreserved    = "((("+alphanum+"|"+mark+")"+")|(("+alphanum+"|"+mark+")"+"[ \\.]?"+"("+alphanum+"|"+mark+")))";//as dot cannot occur at beginning or end in windows
		      String reserved      = "([;\\\\:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
		      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
		      String segment         = "("+unreserved+")*";//replaced pchar
		      String segment_nz         = "("+unreserved+")+";//replaced pchar
		      String path_absolute="(\\\\("+segment_nz+"(\\\\"+segment+")*)?)";
		      String relativepath="("+segment_nz+"(\\\\"+segment+")*)";
		     String drivemarker= "([:\\|])";
		     String driveletter="("+alpha+"("+drivemarker+")?)";
		     String path_abs_win="("+driveletter+path_absolute+")";
		     String localfile="(("+path_abs_win+"|"+path_absolute+"|"+relativepath+"))";//` to denote spl case of : as ads separator
			filepath_spec=localfile;
			
			
			System.out.println("r_spec:"+filepath_spec);
			//String filepath_spec=FetchRegex.getreg("file name");
			
			//Enable for blackbox fuzz testing
			//test2(filepath_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				code_regex=code_regex.replace("`basePath`", "\\\\top");
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+validchar+"|"+splchar+")*";
				filepath_spec=filepath_spec+"&("+validchar+"|"+splchar+")*";
				HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar);
				//DeriveRegex.TestConcat.testall((cnt++)+"con_552"+".txt", teststr);
				}
		}
	
		//ORACLE 19
		static void test_filecolon(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestFileColon";
			//Testing for Unix
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9:_\\-\\./\\~]","[a-zA-Z0-9:_\\-\\./\\~\\\\]");
			String filepath_spec="((\\~?/?)?([a-zA-Z_\\:\\-0-9\\.]*(/[a-zA-Z_\\-0-9\\:\\.]+)*)/?)";//unix
			System.out.println("r_spec:"+filepath_spec);
			//String filepath_spec=FetchRegex.getreg("file name");
			
			//Enable for blackbox fuzz testing
			//test2(filepath_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(filepath_spec);
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(filepath_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|:|"+splchar+")*";
				filepath_spec=filepath_spec+"&("+ip.charset+"|:|"+splchar+")*";
				HashSet<String> teststr=test(filepath_spec,code_regex,totalsplchar);
				//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
				}
		}
		
		//ORACLE 20
		static void test_anchorurl(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
			String sample="DeriveRegex.TestUriAnchor";
			InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9:_\\-\\./\\~!\\#\\?\\@\\&,'\\$=;\\+]","[a-zA-Z0-9:_\\-\\./]");
		      String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphanum      = "("+alpha+"|"+digit+")";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String escaped       = "(%"+hex+hex+")";
		      String mark          = "([\\-_\\.!\\~\\*'\\(\\)])";
		      String unreserved    = "("+alphanum+"|"+mark+")";
		      String reserved      = "([;/:\\?\\@\\&=\\+\\$,])";
		      String uric          = "("+reserved+"|"+unreserved+"|"+escaped+")";
		      String fragment      = "("+uric+")*";
		      String query         = "("+uric+")*";
		      String pchar         = "("+unreserved+"|"+escaped+"|[:\\@\\&=\\+\\$,])";
		      String param         = "("+pchar+")*";
		      String segment       = "(("+pchar+")*(;"+param+")*)";
		      String path_segments = "("+segment+"(/"+segment+")*)";
		      String uric_no_slash = "("+unreserved+"|"+escaped+"|[;\\?\\:\\@\\&=\\+\\$,])";
			  String abs_path      = "(/"+path_segments+")";
		      String opaque_part   = "("+uric_no_slash+"("+uric+")*)";
		      String path          = "("+abs_path+"|"+opaque_part+")?";
		      String port          = "("+digit+")*";
		      String IPv4address   = "(("+digit+")+\\.("+digit+")+\\.("+digit+")+\\.("+digit+"))";
		      String toplabel      = "("+alpha+"|"+alpha+"("+alphanum+"|\\-)*"+alphanum+")";
		      String domainlabel   = "("+alphanum+"|"+alphanum+"("+alphanum+"|\\-)*"+alphanum+")";
		      String hostname      = "(("+domainlabel+"\\.)*"+toplabel+"\\.?)";
		      String host          = "("+hostname+"|"+IPv4address+")";
		      String hostport      = "("+host+"(:"+port+")?)";
		      String userinfo      = "("+unreserved+"|"+escaped+"|[;:\\&=\\+\\$,])*";
		      String server        = "(("+userinfo+"\\@)?"+hostport+")?";
		      String reg_name      = "("+unreserved+"|"+escaped+"|[\\$,;:\\@\\&=\\+])+";
		      String authority     = "("+server+"|"+reg_name+")";
		      String scheme        = "("+alpha+"("+alpha+"|"+digit+"|[\\+\\-\\.])*)";
		      String rel_segment   = "("+unreserved+"|"+escaped+"|[;\\@\\&=\\+\\$,])+";
		      String rel_path      = "("+rel_segment+"("+abs_path+")?)";
		      String net_path      = "(//"+authority+"("+abs_path+")?)";
		      String hier_part     = "(("+net_path+"|"+abs_path+")"+"(\\?"+query+")?)";
		      String relativeURI   = "(("+net_path+"|"+abs_path+"|"+rel_path+")"+"(\\?"+query+")?)";
		      String absoluteURI   = "("+scheme+":("+hier_part+"|"+opaque_part+"))";
		      String URI_reference = "(("+absoluteURI+"|"+relativeURI+")?(\\#"+fragment+")?)";
			String url_spec=URI_reference;
			System.out.println("r_spec:"+url_spec);
			//String url_spec=FetchRegex.getreg("url");
			
			//Enable for blackbox fuzz testing
			//test2(url_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=new LinkedHashSet<Character>();//ip.specialchar;
				for(char c:"/:@#?".toCharArray())
					totalsplchar.add(c);
				totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(url_spec,code_regex,totalsplchar);
				//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
				}
		}
		
	
		//ORACLE 21
		static void test_urlslash(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
				String sample="DeriveRegex.TestUrlSlash";
				//Testing for Unix
				InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9:_\\-\\./\\~!\\#\\?\\@\\&,'\\$=;\\+]","[a-zA-Z0-9:_\\-\\./]");
			      String digit    = "([0-9])";
			      String upalpha  = "([A-Z])";
			      String lowalpha = "([a-z])";
			      String alpha         = "("+lowalpha+"|"+upalpha+")";
			      String alphanum      = "("+alpha+"|"+digit+")";
			      String hex           = "("+digit+"|[A-Fa-f])";
			      String escaped       = "(%"+hex+hex+")";
			      String mark          = "([\\-_\\.!\\~\\*'\\(\\)])";
			      String unreserved    = "("+alphanum+"|"+mark+")";
			      String reserved      = "([;/:\\?\\@\\&=\\+\\$,])";
			      String uric          = "("+reserved+"|"+unreserved+"|"+escaped+")";
			      String fragment      = "("+uric+")*";
			      String query         = "("+uric+")*";
			      String pchar         = "("+unreserved+"|"+escaped+"|[:\\@\\&=\\+\\$,])";
			      String param         = "("+pchar+")*";
			      String segment       = "(("+pchar+")*(;"+param+")*)";
			      String path_segments = "("+segment+"(/"+segment+")*)";
			      String uric_no_slash = "("+unreserved+"|"+escaped+"|[;\\?\\:\\@\\&=\\+\\$,])";
				  String abs_path      = "(/"+path_segments+")";
			      String opaque_part   = "("+uric_no_slash+"("+uric+")*)";
			      String path          = "("+abs_path+"|"+opaque_part+")?";
			      String port          = "("+digit+")*";
			      String IPv4address   = "(("+digit+")+\\.("+digit+")+\\.("+digit+")+\\.("+digit+"))";
			      String toplabel      = "("+alpha+"|"+alpha+"("+alphanum+"|\\-)*"+alphanum+")";
			      String domainlabel   = "("+alphanum+"|"+alphanum+"("+alphanum+"|\\-)*"+alphanum+")";
			      String hostname      = "(("+domainlabel+"\\.)*"+toplabel+"\\.?)";
			      String host          = "("+hostname+"|"+IPv4address+")";
			      String hostport      = "("+host+"(:"+port+")?)";
			      String userinfo      = "("+unreserved+"|"+escaped+"|[;:\\&=\\+\\$,])*";
			      String server        = "(("+userinfo+"\\@)?"+hostport+")?";
			      String reg_name      = "("+unreserved+"|"+escaped+"|[\\$,;:\\@\\&=\\+])+";
			      String authority     = "("+server+"|"+reg_name+")";
			      String scheme        = "("+alpha+"("+alpha+"|"+digit+"|[\\+\\-\\.])*)";
			      String rel_segment   = "("+unreserved+"|"+escaped+"|[;\\@\\&=\\+\\$,])+";
			      String rel_path      = "("+rel_segment+"("+abs_path+")?)";
			      String net_path      = "(//"+authority+"("+abs_path+")?)";
			      String hier_part     = "(("+net_path+"|"+abs_path+")"+"(\\?"+query+")?)";
			      String relativeURI   = "(("+net_path+"|"+abs_path+"|"+rel_path+")"+"(\\?"+query+")?)";
			      String absoluteURI   = "("+scheme+":("+hier_part+"|"+opaque_part+"))";
			      String URI_reference = "(("+absoluteURI+"|"+relativeURI+")?(\\#"+fragment+")?)";
				String url_spec=URI_reference;
				System.out.println("r_spec:"+url_spec);
				//String url_spec=FetchRegex.getreg("url or uri");
				
				//Enable for blackbox fuzz testing
				//test2(url_spec,"",new LinkedHashSet());
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				//System.out.println(filepath_spec);
				int cnt=0;
				while(rIt.hasNext())
					{String code_regex=rIt.next();
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
					//System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
					url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(url_spec,code_regex,totalsplchar);
					//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
					}
				}
				
		//ORACLE 22
		static void test_urldot(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
				String sample="DeriveRegex.TestUrlDots";
				
				InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9:_\\-\\~!\\#\\*\\?\\@\\&,'\\$=;\\+\\./]","[a-zA-Z0-9:_\\*\\-\\~!\\#\\?\\@\\&,'\\$=;\\+\\./]");
			      String digit    = "([0-9])";
			      String upalpha  = "([A-Z])";
			      String lowalpha = "([a-z])";
			      String alpha         = "("+lowalpha+"|"+upalpha+")";
			      String alphanum      = "("+alpha+"|"+digit+")";
			      String hex           = "("+digit+"|[A-Fa-f])";
			      String escaped       = "(%"+hex+hex+")";
			      String mark          = "([\\-_\\.!\\~\\*'\\(\\)])";
			      String unreserved    = "("+alphanum+"|"+mark+")";
			      String reserved      = "([;/:\\?\\@\\&=\\+\\$,])";
			      String uric          = "("+reserved+"|"+unreserved+"|"+escaped+")";
			      String fragment      = "("+uric+")*";
			      String query         = "("+uric+")*";
			      String pchar         = "("+unreserved+"|"+escaped+"|[:\\@\\&=\\+\\$,])";
			      String param         = "("+pchar+")*";
			      String segment       = "(("+pchar+")*(;"+param+")*)";
			      String path_segments = "("+segment+"(/"+segment+")*)";
			      String uric_no_slash = "("+unreserved+"|"+escaped+"|[;\\?\\:\\@\\&=\\+\\$,])";
				  String abs_path      = "(/"+path_segments+")";
			      String opaque_part   = "("+uric_no_slash+"("+uric+")*)";
			      String path          = "("+abs_path+"|"+opaque_part+")?";
			      String port          = "("+digit+")*";
			      String IPv4address   = "(("+digit+")+\\.("+digit+")+\\.("+digit+")+\\.("+digit+"))";
			      String toplabel      = "("+alpha+"|"+alpha+"("+alphanum+"|\\-)*"+alphanum+")";
			      String domainlabel   = "("+alphanum+"|"+alphanum+"("+alphanum+"|\\-)*"+alphanum+")";
			      String hostname      = "(("+domainlabel+"\\.)*"+toplabel+"\\.?)";
			      String host          = "("+hostname+"|"+IPv4address+")";
			      String hostport      = "("+host+"(:"+port+")?)";
			      String userinfo      = "("+unreserved+"|"+escaped+"|[;:\\&=\\+\\$,])*";
			      String server        = "(("+userinfo+"\\@)?"+hostport+")?";
			      String reg_name      = "("+unreserved+"|"+escaped+"|[\\$,;:\\@\\&=\\+])+";
			      String authority     = "("+server+"|"+reg_name+")";
			      String scheme        = "("+alpha+"("+alpha+"|"+digit+"|[\\+\\-\\.])*)";
			      String rel_segment   = "("+unreserved+"|"+escaped+"|[;\\@\\&=\\+\\$,])+";
			      String rel_path      = "("+rel_segment+"("+abs_path+")?)";
			      String net_path      = "(//"+authority+"("+abs_path+")?)";
			      String hier_part     = "(("+net_path+"|"+abs_path+")"+"(\\?"+query+")?)";
			      String relativeURI   = "(("+net_path+"|"+abs_path+"|"+rel_path+")"+"(\\?"+query+")?)";
			      String absoluteURI   = "("+scheme+":("+hier_part+"|"+opaque_part+"))";
			      String URI_reference = "(("+absoluteURI+"|"+relativeURI+")?(\\#"+fragment+")?)";
				String url_spec=URI_reference;
				System.out.println("r_spec:"+url_spec);
				//String url_spec=FetchRegex.getreg("url or uri");
				
				//Enable for blackbox fuzz testing
				//test2(url_spec,"",new LinkedHashSet());
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				//System.out.println(filepath_spec);
				int cnt=0;
				while(rIt.hasNext())
					{String code_regex=rIt.next();
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
					//System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
					url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(url_spec,code_regex,totalsplchar);
					//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
					}
			}
		
		//ORACLE 23
		static void test_jsonquote(String[] args)
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.TestJsonquote";
		//LANG-1395		
		String validchar="[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ \t]";
		InterProcCFG ip=new InterProcCFG(validchar,validchar);
		//for one level of nesting
		String string="((\\\"\\\")|(\\\"([a-zA-Z0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r)+\\\"))";
		String number="(\\-?[0-9]+(\\.[0-9]+)?([eE][\\+\\-][0-9]+)?)";
		String element="("+string+"|"+number+"|(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))";
		String array="((\\[\\])|(\\["+element+"(,"+element+")*]))";//(,"+string+"|"+number+"|"+"(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\["+string+"|"+number+"\\]))*\\]"+"))";
		String pair="("+string+":"+"("+string+"|"+number+"|"+array+"|null|true|false|"+"(\\{"+string+":"+"("+string+"|"+number+"|"+array+"|null|true|false"+")\\})"+"))";
		String pairs="("+pair+"(,"+pair+")*)";
		String json_spec_adv="((\\{\\})|(\\{"+pairs+"\\}))";//"\\{.*\\:\\{.*\\:.*\\}\\}";
	
		String pairb="("+string+":"+"("+string+"))";
		String pairsb="("+pairb+"(,"+pairb+")*)";
		String json_spec="((\\{\\})|(\\{"+pairsb+"\\}))";	
		String json_val="("+string+"|"+number+"|"+array+"|null|true|false|"+"(\\{"+string+":"+"("+string+"|"+number+"|"+array+"|null|true|false"+")\\})"+")";
		
		//System.out.println(json_spec);
		
		//Enable for blackbox fuzz testing
		//test2(json_spec,"",new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			//totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
		//	System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+validchar+")*";
			json_spec=json_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(json_spec,code_regex,totalsplchar);//remove special characters to avoid overhead
		//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
			}
		}
		
	
		//ORACLE 24
		static void test_jsonarr(String[] args) throws Exception
				{//charset: [a-zA-Z0-9_\\-\\.\\\\]
				String sample="DeriveRegex.TestJsonArr";
				//LANG-1395		
				String validchar="[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ \t]";
				InterProcCFG ip=new InterProcCFG(validchar,validchar);
				//for one level of nesting
				String string="((\\\"\\\")|(\\\"([a-zA-Z0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r)+\\\"))";
				String number="(\\-?[0-9]+(\\.[0-9]+)?([eE][\\+\\-][0-9]+)?)";
				String element="("+string+"|"+number+"|(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))";
				String array="((\\[\\])|(\\["+element+"(,"+element+")*]))";//(,"+string+"|"+number+"|"+"(\\{"+string+":("+string+"|"+number+"|null|true|false|(\\[("+string+"|"+number+")(,("+string+"|"+number+"))*\\]))\\})|(\\["+string+"|"+number+"\\]))*\\]"+"))";
				System.out.println("r_spec:"+array);
				//String array=FetchRegex.getreg("json array value");
				
				//System.out.println(json_spec);
				
				//Enable for blackbox fuzz testing
				//test2(array,"",new LinkedHashSet());
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				int cnt=0;
				while(rIt.hasNext())
					{
					String code_regex=rIt.next();
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					//totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
				//	System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+validchar+")*";
					array=array+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(array,code_regex,totalsplchar);//remove special characters to avoid overhead
				//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
					}
				}		
	
		//ORACLE 25
		static void test_headerfield(String[] args) throws Exception
				{//charset: [a-zA-Z0-9_\\-\\.\\\\]
				String sample="DeriveRegex.TestHeaderField";
				//NET-582	
				String validchar="[\u0000a-zA-Z0-9\\<\\>\\@\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ \t]";
				InterProcCFG ip=new InterProcCFG(validchar,validchar);
				String atext="([a-zA-Z0-9!\\#\\$%\\&'\\*\\+\\-/=\\?\\^_`\\{\\}\\|\\~])";
				String atom="( ?"+atext+"+ ?)";
				String dot_atom_text="("+atext+"+(\\."+atext+"+)*)";
				String dot_atom= "( ?"+dot_atom_text+"+ ?)";
				String qtext="([\u0021\u0023-\u005B\u005D-\u007E\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F])"	;				
				String quoted_pair="((\\\\[\u0021-\u007E ])|(\\\\[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]))";
				String qcontent="("+qtext+"|"+quoted_pair+")";
				String quoted_string="( ?\"( ?"+qcontent+")* ?\" ?)";
				String word="("+atom+"|"+quoted_string+")";
				String obs_phrase="("+word+"("+word+"|\\.| )*)";
				String phrase="("+word+"+|"+obs_phrase+")";
				String obs_dtext="([\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]|"+quoted_pair+")";
				String dtext="([\u0021-\u005A\u005E-\u007E]|"+obs_dtext+")";
				String domain_literal="( ?\\[( ?"+dtext+")* ?\\] ?)";
				String obs_domain="("+atom+"(\\."+atom+")*)";
				String domain="("+dot_atom+"|"+domain_literal+"|"+obs_domain+")";
				String obs_localpart="("+word+"(\\."+word+")*)";
				String localpart="("+dot_atom+"|"+quoted_string+"|"+obs_localpart+")";
				String addr_spec="("+localpart+"\\@"+domain+")";
				String display_name=phrase;
				String obs_route="([ ,]*\\@"+domain+"(, ?(\\@"+domain+")?)*:)";
				String obs_angleaddr="( ?\\<"+obs_route+addr_spec+"\\> ?)";
				String angle_addr="(( ?\\<"+addr_spec+"\\> ?)|"+obs_angleaddr+")";
				String name_addr="(("+display_name+")?"+angle_addr+")";
				String mailbox="("+name_addr+"|"+addr_spec+")";
				String obs_grplist="(( ?,)+ ?)";
				String obs_mboxlist="(( ?,)*"+mailbox+"(,( |"+mailbox+")?)*)";
				String mailboxlist="(("+mailbox+"(,"+mailbox+")*"+")|"+obs_mboxlist+")";
				String grouplist="( |"+mailboxlist+"|"+obs_grplist+")";
				String group="("+display_name+":"+"("+grouplist+")?"+", ?)";
				String address="("+mailbox+"|"+group+")";
				String obs_addrlist="(( ?,)*"+address+"(,( |"+address+")?)*)";
				String address_list="(("+address+"(,"+address+")*"+")|"+obs_addrlist+")";
				String to="((To:"+address_list+")|\u0000)";//as this field is optional
				System.out.println("r_spec:"+to);
				//String to=FetchRegex.getreg("to field in smtp header");
				
				//Enable for blackbox fuzz testing
				//test2(to,"",new LinkedHashSet());		
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				int cnt=0;
				while(rIt.hasNext())
					{
					String code_regex=rIt.next();
					if(code_regex.isEmpty())
						code_regex="~\u0000";
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					//totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
				//	System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+validchar+")*";
					to=to+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(to,code_regex,totalsplchar);//remove special characters to avoid overhead
				//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
					}
				}		
	
	
		//ORACLE 26
			static void test_uriext(String[] args) throws Exception
				{//charset: [a-zA-Z0-9_\\-\\.\\\\]
					String sample="DeriveRegex.TestURIext";
					
					//SPR-15786
					InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9:_\\-\\./\\~!\\#\\?\\@\\&,'\\$=;\\+]","[a-zA-Z0-9:_\\-\\./\\~!\\#\\?\\@\\&,'\\$=;\\+]");
				      String digit    = "([0-9])";
				      String upalpha  = "([A-Z])";
				      String lowalpha = "([a-z])";
				      String alpha         = "("+lowalpha+"|"+upalpha+")";
				      String alphanum      = "("+alpha+"|"+digit+")";
				      String hex           = "("+digit+"|[A-Fa-f])";
				      String sub_delims="([!\\$\\&'\\(\\)\\*\\+,;=])";
				      String pct_encoded   = "(%"+hex+hex+")";
				      String mark          = "([\\-_\\.\\~])";
				      String unreserved    = "("+alphanum+"|"+mark+")";
				      String reserved      = "([;/:\\?\\@\\&=\\+\\$,!'\\(\\)\\*\\+,])";
				      String pchar          = "("+reserved+"|"+unreserved+"|"+pct_encoded+")";
				      String fragment      = "("+pchar+"|/|\\?)*";
				      String query         = "("+pchar+"|/|\\?)*";
				      String segment         = "("+pchar+")*";
				      String segment_nz         = "("+pchar+")+";
				      String segment_nz_nc = "("+unreserved+"|"+pct_encoded+"|\\@|"+sub_delims+")+";
				      String path_abempty="(/"+segment+")*";
				      String path_absolute="(/("+segment_nz+"(/"+segment+")*)?)";
				      String path_noscheme="("+segment_nz_nc+"(/"+segment+")*)";
				      String path_rootless="("+segment_nz+"(/"+segment+")*)";
				      String path="("+path_abempty+"|"+path_absolute+"|"+path_noscheme+"|"+path_rootless+"| )";
				      String reg_name      = "("+unreserved+"|"+pct_encoded+"|"+sub_delims+")*";
				      String IPv4address   = "(("+digit+")+\\.("+digit+")+\\.("+digit+")+\\.("+digit+"))";
				      String port          = "("+digit+")*";
				      String h16= "("+hex+"{1,4})";
				  	String ls32="(("+h16+":"+h16+")|"+IPv4address+")";
				  	String IPv6address="((("+h16+":){1,6}"+ls32+")|(::("+h16+":){1,5}"+ls32+")|(("+h16+")?::("+h16+":){1,4}"+ls32+")|((("+h16+":){0,1}"+h16+")?::("+h16+":){1,3}"+ls32+")|((("+h16+":){0,2}"+h16+")?::("+h16+":){1,2}"+ls32+")|((("+h16+":){0,3}"+h16+")?::("+h16+":)"+ls32+")|((("+h16+":){0,4}"+h16+")?::"+ls32+")|((("+h16+":){0,5}"+h16+")?::"+h16+")|((("+h16+":){0,6}"+h16+")?::))";
				  	String userinfo      = "("+unreserved+"|"+pct_encoded+"|[;:\\&=\\+\\$,])*";
				  	 String IPvFuture="(v("+hex+")+\\.("+unreserved+"|"+sub_delims+"|:)+)";
				     String IP_literal="(\\[("+IPv6address+"|"+IPvFuture+")\\])";
				  	String host="("+IP_literal+"|"+IPv4address+"|"+reg_name+")";
				  	String authority="(("+userinfo+"\\@)?"+host+"(:"+port+"))";
				    String scheme        = "("+alpha+"("+alpha+"|"+digit+"|[\\+\\-\\.])*)";
				    String relative_part="(//"+authority+path_abempty+"|"+path_absolute+"|"+path_noscheme+"| )";
					String relative_ref="("+relative_part+"(\\?"+query+"(\\#"+fragment+")?)?)";
					String url_spec=path;
					System.out.println(url_spec);
					//String url_spec=FetchRegex.getreg("uri path");
					
					//Enable for blackbox fuzz testing
					//test2(url_spec,"",new LinkedHashSet());
					Iterator<String> rIt=ip.sootcall(sample, args).iterator();
					//System.out.println(filepath_spec);
					int cnt=0;
					while(rIt.hasNext())
						{String code_regex=rIt.next();
						LinkedHashSet<Character> totalsplchar=new LinkedHashSet<Character>();//ip.specialchar;
						totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
						//System.out.println("Total spl "+totalsplchar);
						String splchar=getsplchar(totalsplchar);
						code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
						url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
						HashSet<String> teststr=test(url_spec,code_regex,totalsplchar);
						//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
					
						}
				}
	
	//ORACLE 27		
	static void test_keyval(String[] args) throws Exception
			{//charset: [a-zA-Z0-9/\\+=:]
				String sample="DeriveRegex.TestKeyVal";
				InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9/\\+:=]","[a-zA-Z0-9/\\+:=`]");
				String[] spl={"=",":"};
				String usrpss_spec="(([a-zA-Z0-9/\\+]+[`][a-zA-Z0-9/\\+:=]*))";//treat` as special char denoting [:=] as we need a way to differentiate between the separator char and non sep char 
				//System.out.println(usrpss_spec1);
				//String usrpss_spec=FetchRegex.getreg("key value pair");
				System.out.println("r_spec:"+usrpss_spec);
				
				//System.out.println("Testing "+sample);
				
				//Enable for blackbox fuzz testing
				//test2(usrpss_spec,"", new LinkedHashSet());
				Iterator<String> rIt=ip.sootcall(sample, args).iterator();
				int cnt=0;
				while(rIt.hasNext())
					{
					String code_regex=rIt.next();
					LinkedHashSet<Character> totalsplchar=ip.specialchar;
					totalsplchar.addAll(getdistinctspec(usrpss_spec,code_regex));
					//System.out.println("Total spl "+totalsplchar);
					String splchar=getsplchar(totalsplchar);
					code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
					usrpss_spec=usrpss_spec+"&("+ip.charset+"|"+splchar+")*";
					HashSet<String> teststr=test(usrpss_spec,code_regex,totalsplchar,spl);
					//DeriveRegex.TestEnvirPair.testall((cnt++)+"keyval_6121"+".txt", teststr);
					}
			}
	//ORACLE 28
	static void test_jsonescape(String[] args) throws Exception
	{//charset: [a-zA-Z0-9_\\-\\.\\\\]
	String sample="DeriveRegex.TestJSONEscape";
		
	String validchar="[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/ ]";
	InterProcCFG ip=new InterProcCFG("[a-zA-Z0-9\\}\\{\\[\\]:\\+\\-,/ \"\\\\]",validchar);
	//for one level of nesting
	String string="((\\\"\\\")|(\\\"([a-zA-Z0-9,]|\\/|\\\"|\\\\|[\u0001-\u0020\u007F]|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r)+\\\"))";
	
	String pairb="("+string+":"+"("+string+"))";
	String pairsb="("+pairb+"(,"+pairb+")*)";
	String json_spec="((\\{\\})|(\\{"+pairsb+"\\}))";	
	//String json_spec="((\\{\\})|(\\{((((\\\"\\\")|(\\\"([a-zA-A0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r|([À€- ]))+\\\")):(((\\\"\\\")|(\\\"([a-zA-A0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r|([À€- ]))+\\\"))))(,(((\\\"\\\")|(\\\"([a-zA-A0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r|([À€- ]))+\\\")):(((\\\"\\\")|(\\\"([a-zA-A0-9,]|\\\\/|\\\"|\\\\\\\\|\\\\b|\\\\t|\\\\f|\\\\n|\\\\r|([À€- ]))+\\\")))))*)\\}))";
	//System.out.println(json_spec1);
	//String json_spec=FetchRegex.getreg("json");

	System.out.println("r_spec:"+json_spec);
	
	//Enable for blackbox fuzz testing
	//test2(json_spec,"",new LinkedHashSet());
	Iterator<String> rIt=ip.sootcall(sample, args).iterator();
	int cnt=0;
	while(rIt.hasNext())
		{
		String code_regex=rIt.next();
		LinkedHashSet<Character> totalsplchar=new LinkedHashSet<Character>();
		totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
		//totalsplchar.addAll(ip.specialchar);
	//	System.out.println("Total spl "+totalsplchar);
		String splchar=getsplchar(ip.specialchar);
		code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
		HashSet<String> teststr=test(json_spec,code_regex,totalsplchar);//remove special characters to avoid overhead
	//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
		}
	}

	//ORACLE29
	static void test_validurl(String[] args) throws Exception
	{
		String sample="DeriveRegex.TestValidUrl";
		InterProcCFG ip=new InterProcCFG("[\u0020-\u007E]","[\u0020-\u007E]");
		String digit    = "([0-9])";
	      String upalpha  = "([A-Z])";
	      String lowalpha = "([a-z])";
	      String alpha         = "("+lowalpha+"|"+upalpha+")";
	      String alphadigit      = "("+alpha+"|"+digit+")";
	      String digits="[0-9]+";
	      String hex           = "("+digit+"|[A-Fa-f])";
	      String escape       = "(%"+hex+hex+")";
	      String mark          = "([\\-_\\.!\\*'\\(\\)\\+\\$,])";
	      String unreserved    = "("+alphadigit+"|"+mark+")";
	      String reserved      = "([;/:\\?\\@\\&=])";
	      String xchar="("+unreserved+"|"+reserved+"|"+escape+")";
	      String uchar="("+unreserved+"|"+escape+")";
	      String urlpath="("+xchar+")*";
	      String user="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
	      String password="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
	      String port=digits;
	      String hostnumber="("+digits+"\\."+digits+"\\."+digits+"\\."+digits+")";
	      String toplabel="("+alpha+"|"+"("+alpha+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
	      String domainlabel="("+alphadigit+"|"+"("+alphadigit+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
	      String hostname="(("+domainlabel+"\\.)*"+toplabel+")";
	      String host="("+hostname+"|"+hostnumber+")";
	      String hostport="("+host+"(:"+port+")?"+")";
	      String login="("+"("+user+"(:"+password+")?"+"\\@)?"+")";
	      String ftptype="[AIDaid]";
	      String fsegment="("+uchar+"|"+"[\\?:\\@\\&=])*";
	      String fpath="("+fsegment+"(/"+fsegment+")*)";
	      String ftpurl="(ftp://"+login+"(/"+fpath+"(;type="+ftptype+")?)?)";
	      String fileurl="(file://"+"("+host+"|localhost)?/"+fpath+")";
	      String search="("+uchar+"|[;:\\@\\&=])*";
	      String hsegment="("+uchar+"|[;:\\@\\&=])*";
	      String hpath="("+hsegment+"(/"+hsegment+")*)";
	      String httpurl="(http://"+hostport+"(/"+hpath+"(\\?"+search+")?)?)";
	      String encoded822addr="("+xchar+")+";
	      String mailtourl="(mailto:"+encoded822addr+")";
	      String telneturl="(telnet://"+login+"(/)?)";
	      String url="("+httpurl+"|"+ftpurl+"|"+telneturl+"|"+mailtourl+"|"+fileurl+")";
	      String url_spec=url;
	    System.out.println("r_spec:"+url_spec);
		//String url_spec=FetchRegex.getreg("url");
		
	  //Enable for blackbox fuzz testing
		//test2(url_spec,"",new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		int cnt=0;
		while(rIt.hasNext())
			{String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=new LinkedHashSet<Character>();//ip.specialchar;
			for(char c:"/:@#?".toCharArray())
				totalsplchar.add(c);
			totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
			//System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
			url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(url_spec,code_regex,totalsplchar);
			//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
			}

	}
	
	//ORACLE 30
		static void test_ValidIPV6(String[] args) throws Exception
		{//charset:[0-9A-Fa-f:\\.]
			String sample="DeriveRegex.TestValidIPV6";
			//Code inferred regex
			String validchar="[0-9A-Fa-f:\\./%]";
			InterProcCFG ip=new InterProcCFG("[0-9A-Fa-f:\\.]",validchar);
			String ip_specv6="((((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])(\\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])){3}))|:))))([%/][0-9A-Fa-f]+)?)";
			String ipv="("+ip_specv6+")";
			System.out.println("r_spec:"+ipv);
			//String ipv=FetchRegex.getreg("ipv6 address");
			
			//Enable for blackbox fuzz testing
			//test2(ipv,"", new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			//System.out.println(ipv);
			int cnt=0;
			while(rIt.hasNext())
				{
				String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(ipv,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				ipv=ipv+"&("+ip.charset+"|[/%]"+"|"+splchar+")*";
				//System.out.println(code_regex);
				HashSet<String> teststr=test(ipv,code_regex,totalsplchar);
				//DeriveRegex.TestIPV6address.testall((cnt++)+"ipv6_1557"+".txt", teststr);
				}
		}
		
		//ORACLE 31
		static void test_LANG1395(String[] args) throws Exception
		{//charset: [a-zA-Z0-9_\\-\\.\\\\]
		String sample="DeriveRegex.Test_LANG1395";
			
		String validchar="[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/]";
		InterProcCFG ip=new InterProcCFG(validchar,"[a-zA-Z0-9\\}\\{\\\"\\[\\]:\\+\\-,\\\\/`]");//denoting ` is a way to assign higher priority to certain characters
		//for one level of nesting
		String string="(([a-zA-Z0-9,\\}\\{\\[\\]\\:\\+\\-\\\\/\\\"]|`)*)";
		String json_val=string;	
		String[] spl={"\\/","\\\"","\\\\","\\b","\\t","\\f","\\n","\\r","\\u0000"};
		//System.out.println(json_spec1);
		//String json_spec=FetchRegex.getreg("json");

		//System.out.println(json_spec);
		
		//Enable for blackbox fuzz testing
		//test2(json_val,"",new LinkedHashSet());
		Iterator<String> rIt=ip.sootcall(sample, args).iterator();
		int cnt=0;
		while(rIt.hasNext())
			{
			String code_regex=rIt.next();
			LinkedHashSet<Character> totalsplchar=ip.specialchar;
			//totalsplchar.addAll(getdistinctspec(json_spec,code_regex));
		//	System.out.println("Total spl "+totalsplchar);
			String splchar=getsplchar(totalsplchar);
			if(code_regex.isEmpty())
				code_regex="("+validchar+")*";
			else
				code_regex=code_regex+"&("+validchar+")*";
			//json_spec=json_spec+"&("+ip.charset+"|"+splchar+")*";
			HashSet<String> teststr=test(json_val,code_regex,totalsplchar,spl);//remove special characters to avoid overhead
		//	DeriveRegex.TestJsonparser.testall((cnt++)+"json_12297_11992"+".txt", teststr);
			}
		}

		//ORACLE32
		static void test_urlbuilder5(String[] args) throws Exception
		{
			String sample="DeriveRegex.Test_URLbuilder5";
			//rfc1738
			InterProcCFG ip=new InterProcCFG("[ \u0024-\u005A_!\u0061-\u007A]","[\u0020-\u007E]");
		      String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphadigit      = "("+alpha+"|"+digit+")";
		      String digits="[0-9]+";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String escape       = "(`"+hex+hex+")";
		      String mark          = "([\\-_\\.!\\*'\\(\\)\\+\\$,])";
		      String unreserved    = "("+alphadigit+"|"+mark+")";
		      String reserved      = "([;/:\\?\\@\\&=])";
		      String xchar="("+unreserved+"|"+reserved+"|"+escape+")";
		      String uchar="("+unreserved+"|"+escape+")";
		      String urlpath="("+xchar+")*";
		      String user="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
		      String password="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
		      String port=digits;
		      String hostnumber="("+digits+"\\."+digits+"\\."+digits+"\\."+digits+")";
		      String toplabel="("+alpha+"|"+"("+alpha+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
		      String domainlabel="("+alphadigit+"|"+"("+alphadigit+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
		      String hostname="(("+domainlabel+"\\.)*"+toplabel+")";
		      String host="("+hostname+"|"+hostnumber+")";
		      String hostport="("+host+"(:"+port+")?"+")";
		      String login="("+"("+user+"(:"+password+")?"+"\\@)?"+")";
		      String ftptype="[AIDaid]";
		      String fsegment="("+uchar+"|"+"[\\?:\\@\\&=])*";
		      String fpath="("+fsegment+"(/"+fsegment+")*)";
		      String ftpurl="(ftp://"+login+"(/"+fpath+"(;type="+ftptype+")?)?)";
		      String fileurl="(file://"+"("+host+"|localhost)?/"+fpath+")";
		      String search="("+uchar+"|[;:\\@\\&=])*";
		      String hsegment="("+uchar+"|[;:\\@\\&=])*";
		      String hpath="("+hsegment+"(/"+hsegment+")*)";
		      String httpurl="(http://"+hostport+"(/"+hpath+"(\\?"+search+")?)?)";
		      String encoded822addr="("+xchar+")+";
		      String mailtourl="(mailto:"+encoded822addr+")";
		      String telneturl="(telnet://"+login+"(/)?)";
		      String url="("+httpurl+"|"+ftpurl+"|"+telneturl+"|"+mailtourl+"|"+fileurl+")";
		      String url_spec=url;
			System.out.println("r_spec:"+url_spec);
			//String url_spec=FetchRegex.getreg("url");
			String[] spl={"%"};// taking spl characters obtained from code as separate to test if manipulation correct
			
			//Enable for blackbox fuzz testing
			//test2(url_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				//url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(url_spec,code_regex,totalsplchar,spl);
				//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
				}

		}
		

		//ORACLE33
		static void test_urlbuilder39(String[] args) throws Exception
		{
			String sample="DeriveRegex.Test_UrlBuilder39";
			//rfc1738
			InterProcCFG ip=new InterProcCFG("[ \u0024-\u005A_!\u0061-\u007A]","[\u0020-\u007E]");
		      String digit    = "([0-9])";
		      String upalpha  = "([A-Z])";
		      String lowalpha = "([a-z])";
		      String alpha         = "("+lowalpha+"|"+upalpha+")";
		      String alphadigit      = "("+alpha+"|"+digit+")";
		      String digits="[0-9]+";
		      String hex           = "("+digit+"|[A-Fa-f])";
		      String escape       = "(%"+hex+hex+")";
		      String mark          = "([\\-_\\.!\\*'\\(\\)`\\$,])";
		      String unreserved    = "("+alphadigit+"|"+mark+")";
		      String reserved      = "([;/:\\?\\@\\&=])";
		      String xchar="("+unreserved+"|"+reserved+"|"+escape+")";
		      String uchar="("+unreserved+"|"+escape+")";
		      String urlpath="("+xchar+")*";
		      String user="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
		      String password="(("+uchar+"|"+"[;\\?\\&=]"+")*)";
		      String port=digits;
		      String hostnumber="("+digits+"\\."+digits+"\\."+digits+"\\."+digits+")";
		      String toplabel="("+alpha+"|"+"("+alpha+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
		      String domainlabel="("+alphadigit+"|"+"("+alphadigit+"("+alphadigit+"|"+"\\-"+")*"+alphadigit+"))";
		      String hostname="(("+domainlabel+"\\.)*"+toplabel+")";
		      String host="("+hostname+"|"+hostnumber+")";
		      String hostport="("+host+"(:"+port+")?"+")";
		      String login="("+"("+user+"(:"+password+")?"+"\\@)?"+")";
		      String ftptype="[AIDaid]";
		      String fsegment="("+uchar+"|"+"[\\?:\\@\\&=])*";
		      String fpath="("+fsegment+"(/"+fsegment+")*)";
		      String ftpurl="(ftp://"+login+"(/"+fpath+"(;type="+ftptype+")?)?)";
		      String fileurl="(file://"+"("+host+"|localhost)?/"+fpath+")";
		      String search="("+uchar+"|[;:\\@\\&=])*";
		      String hsegment="("+uchar+"|[;:\\@\\&=])*";
		      String hpath="("+hsegment+"(/"+hsegment+")*)";
		      String httpurl="(http://"+hostport+"(/"+hpath+"(\\?"+search+")?)?)";
		      String encoded822addr="("+xchar+")+";
		      String mailtourl="(mailto:"+encoded822addr+")";
		      String telneturl="(telnet://"+login+"(/)?)";
		      String url="("+httpurl+"|"+ftpurl+"|"+telneturl+"|"+mailtourl+"|"+fileurl+")";
		      String url_spec=url;
			System.out.println("r_spec:"+url_spec);
			//String url_spec=FetchRegex.getreg("url");
			String[] spl={"+"};// taking spl characters obtained from code as separate to test if manipulation correct
			
			//Enable for blackbox fuzz testing
			//test2(url_spec,"",new LinkedHashSet());
			Iterator<String> rIt=ip.sootcall(sample, args).iterator();
			int cnt=0;
			while(rIt.hasNext())
				{String code_regex=rIt.next();
				LinkedHashSet<Character> totalsplchar=ip.specialchar;
				totalsplchar.addAll(getdistinctspec(url_spec,code_regex));
				//System.out.println("Total spl "+totalsplchar);
				String splchar=getsplchar(totalsplchar);
				code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
				//url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
				HashSet<String> teststr=test(url_spec,code_regex,totalsplchar,spl);
				//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
				}

		}

		//ORACLE34
				static void test_greenmail213(String[] args) throws Exception
				{
					String sample="DeriveRegex.Test_greenmail213";
					//rfc1738
					InterProcCFG ip=new InterProcCFG("[ \\#\\,\\-\\./0-9A-Za-z:;\\@\\<\\>\\\"]","[\u0020-\u007E]");
					String qtext="([\\#\\,\\-\\./0-9A-Za-z ])";
					String atext="([a-zA-Z0-9//-])";
					String atom="("+atext+")+";
					String dot_atom_text="(("+atext+")+(\\.("+atext+")+)*)";
					String dot_atom=dot_atom_text;
					String dtext="([\\#\\,\\-\\./0-9A-Za-z])";										
					String obs_text="([\\#\\,\\-\\./0-9A-Za-z]*)";
					String text=obs_text;
					//String obs_qp="(\\\\[\\!\\\"\\#\\,\\-\\./0-9A-Za-z:;])";
					String quoted_pair="(\\\\"+text+")";
					//String qcontent="("+qtext+"|"+quoted_pair+")";
					String quoted_string="(\\\"("+qtext+")*\\\")";						
					String word="(("+atom+")+|("+quoted_string+")+)";
					//String obs_char="([\\!\\\"\\#\\,\\-\\./0-9A-Za-z:;])";
					//String obs_phrase="("+word+"("+word+"|"+"[\\. ]"+")*)";
					String phrase="("+word+")";
					//String obs_local_part="("+word+"(\\."+word+")*)";
					String domain="("+atom+"(\\."+atom+")*)";
					//String dcontent="("+dtext+"|"+quoted_pair+")";
					//String domain_literal="(\\[("+dcontent+")*\\])";
					//String domain="("+dot_atom+"|"+domain_literal+")";
					//String obs_domain_list="(\\@"+domain+"(([ \\,])* ?\\@"+domain+")*"+")";
					//String obs_route="( ?"+obs_domain_list+": ?)";
					String local_part="("+dot_atom+")";
					String addr_spec="("+local_part+"\\@"+domain+")";
					//String obs_angle_addr="(\\<"+obs_route+"?"+addr_spec+"\\>)";
					String display_name=phrase;
					String angle_addr="( ?\\<"+addr_spec+"\\> ?)";	
					String name_addr="(("+display_name+")?"+angle_addr+")";
					String mailbox="("+name_addr+"|"+addr_spec+")";
					//String obs_mbox_list="((("+mailbox+")? ?, ?)+"+mailbox+"?)";
					String mailbox_list="(("+name_addr+"(`"+name_addr+")*)|"+"("+addr_spec+"(`"+addr_spec+")*))";
					//String group="("+display_name+":"+"("+mailbox_list+"| ?)?; ?)";
					String address="("+mailbox+"|"+mailbox_list+")";
					String emailadd_spec=address;
					System.out.println("r_spec:"+emailadd_spec);
					//String url_spec=FetchRegex.getreg("url");
					String[] spl={","};// taking spl characters obtained from code as separate to test if manipulation correct
					
					//Enable for blackbox fuzz testing
					//test2(emailadd_spec,"",new LinkedHashSet());
					Iterator<String> rIt=ip.sootcall(sample, args).iterator();
					int cnt=0;
					while(rIt.hasNext())
						{String code_regex=rIt.next();
						LinkedHashSet<Character> totalsplchar=ip.specialchar;
						totalsplchar.addAll(getdistinctspec(emailadd_spec,code_regex));
						//System.out.println("Total spl "+totalsplchar);
						String splchar=getsplchar(totalsplchar);
						code_regex=code_regex+"&("+ip.charset+"|"+splchar+")*";
						//url_spec=url_spec+"&("+ip.charset+"|"+splchar+")*";
						HashSet<String> teststr=test(emailadd_spec,code_regex,totalsplchar,spl);
						//DeriveRegex.TestFileColon.testall((cnt++)+"col_483"+".txt", teststr);
						}

				}		
	
	static HashSet<String> test(String specregex, String coderegex, LinkedHashSet<Character> specialChar)
	{
		Automaton p2=new RegExp(specregex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r2= new RunAutomaton(p2);
		Automaton p3=new RegExp(coderegex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r3= new RunAutomaton(p3);
	
		//	System.out.println("-->"+r2.run("16502	530000"));
		//System.out.println(r2.run("{\"abc\":\"fila,ab\",\"boo\":4}"));
		Automaton ex= getexclusive(specregex,coderegex);
		//System.out.println(ex.getNumberOfTransitions());
		RunAutomaton rex=new RunAutomaton(ex);
		//System.out.println(SpecialOperations.getStrings(ex,10));
		System.out.println("Get exclusive automaton\n"+ rex.run("{\"1e\":\"k1\"\",\",T\"}"));
		ArrayList<String> teststr=new StringGenerate(ex).generate(specialChar,rex,false);
		compliancewith(teststr,coderegex,specregex,rex);
		return new LinkedHashSet<String>(teststr);
		/*System.out.println("Enter string to test for acceptance: ");
		Scanner sc=new Scanner(System.in);
		String teststr="";
		teststr=sc.nextLine();
		System.out.println("Match found: "+rex.run(teststr));
		*///sc.close();
	}
	
	static HashSet<String> test(String specregex, String coderegex, LinkedHashSet<Character> specialChar,String[] spl)
	{
		Automaton p2=new RegExp(specregex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r2= new RunAutomaton(p2);
		Automaton p3=new RegExp(coderegex,RegExp.ALL).toAutomaton(true);
		RunAutomaton r3= new RunAutomaton(p3);
	
		//	System.out.println("-->"+r2.run("16502	530000"));
		//System.out.println(r2.run("{\"abc\":\"fila,ab\",\"boo\":4}"));
		Automaton ex= getexclusive(specregex,coderegex);
		//System.out.println(ex.getNumberOfTransitions());
		RunAutomaton rex=new RunAutomaton(ex);
		//System.out.println(SpecialOperations.getStrings(ex,10));
		System.out.println("Get exclusive automaton\n"+ r2.run("http://8.1EBi-31.be.M9B:24/?`Ca"));
		HashSet<String> teststr=new LinkedHashSet<String>(new StringGenerate(ex).generate(specialChar,rex,false));
		compliancewith(teststr,coderegex,specregex,rex,spl);
		return teststr;
		/*System.out.println("Enter string to test for acceptance: ");
		Scanner sc=new Scanner(System.in);
		String teststr="";
		teststr=sc.nextLine();
		System.out.println("Match found: "+rex.run(teststr));
		*///sc.close();
	}
//For random testing comparison
	static HashSet<String> test2(String specregex, String coderegex, LinkedHashSet<Character> specialChar)
	{
		Automaton a1=new RegExp(specregex,RegExp.ALL).toAutomaton();
		RunAutomaton rex=new RunAutomaton(a1);
		String s="tel:+98 10625811";
		//System.out.println(rex.run(s));
		//System.out.println("Get exclusive automaton\n"+ rex);
		ArrayList<String> teststr=new StringGenerate(a1).generate(specialChar,rex,true);
		compliancewith(teststr,coderegex,specregex,rex);
		return new LinkedHashSet<String>(teststr);

	}

	
	static Automaton getexclusive(String s1, String s2)
	{
		Automaton a1=new RegExp(s1,RegExp.ALL).toAutomaton();
		Automaton a2=new RegExp(s2,RegExp.ALL).toAutomaton();
		Automaton intersect=BasicOperations.intersection(a1, a2);
		Automaton union=BasicOperations.union(a1, a2);
		Automaton result= BasicOperations.minus(union, intersect);
		return result;
	}

	static void finddiff(String s, String rs, String rp)
	{
		Automaton p=new RegExp(rs,RegExp.ALL).toAutomaton();
		RunAutomaton r= new RunAutomaton(p);
		System.out.println("from first: "+ r+"\n"+r.run(s));
		Automaton p2=new RegExp(rp,RegExp.ALL).toAutomaton();
		RunAutomaton r2= new RunAutomaton(p2);
		System.out.println("from second: "+ r2+"\n"+r2.run(s));
		Automaton diff=BasicOperations.minus(p, p2);
		RunAutomaton rd= new RunAutomaton(diff);
		System.out.println("difference: "+rd);
		System.out.println(diff.run(s));
		
	}
	/*
	 * Separates test strings accepted by implementation and documentation separately
	 */
	static Tuple compliancewith(ArrayList<String> teststr,String codereg,String specreg, RunAutomaton rex)
	{
		ArrayList<String> code=new ArrayList<String>();
		ArrayList<String> doc=new ArrayList<String>();
		Tuple<ArrayList<String>,ArrayList<String>> separatedstr=new Tuple(code,doc);
		Automaton c=new RegExp(codereg,RegExp.ALL).toAutomaton();
		RunAutomaton rc= new RunAutomaton(c);
		Automaton s=new RegExp(specreg,RegExp.ALL).toAutomaton();
		RunAutomaton rs= new RunAutomaton(s);
		LinkedHashSet<String> teststr_set=new LinkedHashSet<String>(teststr);
		int ctr=1;
		for(String str:teststr_set)
		{
			if(rc.run(str) && !rs.run(str))
				{
				if(ctr%2==1)
					code.add(str);
				}
			else if(rs.run(str) && !rc.run(str))
				{
				if(ctr%2==1)
					doc.add(str);
				}
			else if(!rc.run(str) && !rs.run(str) && !rex.run(str))
				System.out.println("-->"+str);
		ctr++;
		}
		System.out.println("**TESTSTRINGS complying with code");
		for(String st: (code))
				System.out.println(st);
		System.out.println("**TESTSTRINGS complying with specifications");
		for(String st: (doc))
				System.out.println(st);
		System.out.println("\n"+teststr_set.size()+":"+code.size()+":"+doc.size()+"\n");
		return separatedstr;
	}
	
	
	static Tuple compliancewith(HashSet<String> teststr,String codereg,String specreg, RunAutomaton rex,String[] spl)
	{
		ArrayList<String> code=new ArrayList<String>();
		ArrayList<String> doc=new ArrayList<String>();
		Tuple<ArrayList<String>,ArrayList<String>> separatedstr=new Tuple(code,doc);
		Automaton c=new RegExp(codereg,RegExp.ALL).toAutomaton();
		RunAutomaton rc= new RunAutomaton(c);
		Automaton s=new RegExp(specreg,RegExp.ALL).toAutomaton();
		RunAutomaton rs= new RunAutomaton(s);
		String tmp="";
		LinkedHashSet<String> teststr_set=new LinkedHashSet<String>(teststr);
		int ctr=1;
		for(String str:teststr_set)
		{	for(String sp:spl)
			{
			if(rc.run(str) && !rs.run(str))
				{tmp=str.replace("`", sp);
				if(!code.contains(tmp) && !doc.contains(tmp) && ctr%2==1)
					code.add(tmp);
				}
			else if(rs.run(str) && !rc.run(str))
				{
				tmp=str.replace("`", sp);
				if(!code.contains(tmp) && !doc.contains(tmp) && ctr%2==1)
					doc.add(tmp);
				}
			else if(!rc.run(str) && !rs.run(str) && !rex.run(str))
				System.out.println("-->"+str);
		ctr++;
			}
		}
		System.out.println("**TESTSTRINGS complying with code");
		for(String st: (code))//hashcode on String is deterministic, order of insertion varies minimally
			System.out.println(st);
		
		System.out.println("**TESTSTRINGS complying with specifications");
		for(String st: (doc))
			System.out.println(st);
		System.out.println("\n"+teststr.size()+":"+code.size()+":"+doc.size()+"\n");
		return separatedstr;
	}
	
	static String getsplchar(HashSet<Character> specialchar)
	{
		String splchar="";
		for(char c:specialchar)
		{
			if(c=='\u0000')
				continue;
			if(MapRegex.needescapechars.contains(Character.toString(c)))
				splchar=splchar.concat("\\"+Character.toString(c));
			else
				splchar=splchar.concat(Character.toString(c));
		}
		if(splchar.length()>0)
			splchar="["+splchar+"]";
		else
			splchar="()";
	//	System.out.println(splchar);
		return splchar;
	}
	
	/**Take the regex from spec and code and
	 * returns spl char of spec that are not
	 * present in codereg
	 **/
	static HashSet<Character> getdistinctspec(String specreg,String codereg)
	{
		HashSet<Character> spec=new LinkedHashSet();
		for(char c:specreg.toCharArray())
		{
			spec.add(c);
		}
		HashSet<Character> code=new LinkedHashSet();
		for(char c:codereg.toCharArray())
		{
			code.add(c);
		}
		spec.removeAll(code);//Take set difference
		String sc;
		HashSet<Character> h=(HashSet<Character>) spec.clone();
		for(char c: h)
		{	sc=Character.toString(c);
			if(MapRegex.needescapechars.contains(sc))
			{
				if(!specreg.contains("\\"+sc))
				{
					spec.remove(c);
				}
			}
			if((c>=48 && c<=57)||(c>=65 && c<=90)||(c>=97 && c<=122))//ignore alphanumeric
				spec.remove(c);
		}
		return spec;
		
	}
	void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
