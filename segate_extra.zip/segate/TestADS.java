package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;

public class TestADS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//IO567
		System.out.println(FilenameUtils.getExtension("Desktop\\innocent.txt:evil"));//colon is valid for windows for ads separator
		//System.out.println(FilenameUtils.getExtension("S:\\s.4s_\\sSSs\\_44.S-:s4"));//colon is valid for windows for ads separator
		/*int i;
		for(i=0;i<args.length;i++)
		{
		try{
			System.out.println(args[i]+" "+FilenameUtils.getExtension(args[i]));//colon is valid for windows for ads separator
			}
		catch(Exception e)
			{
			System.out.println(e.toString());
			}
		}
	*/}
	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+FilenameUtils.getExtension(s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
