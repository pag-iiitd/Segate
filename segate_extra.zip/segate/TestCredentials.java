package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.codec.Base64;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;

public class TestCredentials {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BasicHttpAuthenticationFilter b=new BasicHttpAuthenticationFilter();
		//generated test input results in returning incomplete password
		//SHIRO-375
		System.out.println(b.getPrincipalsAndCredentials( HttpServletRequest.BASIC_AUTH, new String(Base64.encode(("UC:+8CsZU:F93").getBytes())))[1]);
	//	b.getPrincipalsAndCredentials( HttpServletRequest.BASIC_AUTH, "dev:son");
		int i=0;
		/*for(i=0;i<args.length;i++)
		{
		try{
			System.out.println(args[i]+" "+b.getPrincipalsAndCredentials(HttpServletRequest.BASIC_AUTH, new String(Base64.encode(args[i].getBytes())))[1]);
			}
		catch(Exception e)
			{
			System.out.println(args[i]+e.toString());
			}
		}
*/		
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		BasicHttpAuthenticationFilter b=new BasicHttpAuthenticationFilter();
		
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+b.getPrincipalsAndCredentials( HttpServletRequest.BASIC_AUTH, new String(Base64.encode((s).getBytes())))[1]+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
