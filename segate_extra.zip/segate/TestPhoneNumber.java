package DeriveRegex;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import com.google.common.net.InetAddresses;
import com.google.i18n.phonenumbers.*;
public class TestPhoneNumber {

	public static void main(String[] args) throws NumberParseException {
		// TODO Auto-generated method stub
		//libphonenumber-1672
		PhoneNumberUtil pn=PhoneNumberUtil.getInstance();
		System.out.println(pn.parse("tel:+443-4678", "US"));
		//System.out.println(pn.parse("16502	530000", "US"));
		//System.out.println(pn.parse("tel:7042;phone-context=example.com", "US"));
		//System.out.println(pn.parse("tel:6*-44;isub=4;phone-context=555;isub=4;", "US"));
		//System.out.println(pn.parse("tel:+).4.)4;mS;e4-=$;i=[!$s]~X(_;isub=%4C,%44s~!;SS-4s=!(%C4;ext:", "US"));
		
		
	}
	public static void testall(String fname,HashSet<String> teststr)
	{
		PhoneNumberUtil pn=PhoneNumberUtil.getInstance();
		
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				writeToFile(fname,s+"\t-->\t"+pn.parse(s, "US")+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
