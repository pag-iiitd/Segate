package DeriveRegex;
import java.io.IOException;

import com.google.common.io.Files;


public class TestFileExtension {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//Guava1462
			System.out.println(Files.getFileExtension("S:\\4444"));
	}
}
