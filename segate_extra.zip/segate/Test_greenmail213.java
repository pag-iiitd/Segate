package DeriveRegex;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;

import com.icegreen.greenmail.store.SimpleMessageAttributes;
import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.GreenMailUtil;
import com.icegreen.greenmail.util.ServerSetupTest;

public class Test_greenmail213 {

	public static void main(String[] args) throws MessagingException {
		// TODO Auto-generated method stub
		GreenMail greenMail = new GreenMail(ServerSetupTest.SMTP_IMAP);
		 
	/*         greenMail.setUser("foo@localhost", "pwd");
	         greenMail.start();
	      // GreenMailUtil.sendTextEmail("\"Foo, Bar\" <foo@localhost>", "\"Bar, Foo\" <bar@localhost>", "Test subject", "Test message", ServerSetupTest.SMTP);
	           
	         GreenMailUtil.sendTextEmail(" <55-.-@55-.-> ,55 <55-.-@55-.-> ,\"2 \"\"#,2 \" <55-.-@55-.-> ,\"#,8 \" <55-.-@55-.->", "\"Bar, Foo\" <bar@localhost>",  "Test subject", "Test message", ServerSetupTest.SMTP);
	         greenMail.waitForIncomingEmail(1);
	*/     ///System.out.println(greenMail.getReceivedMessages()[0].getSender());
	         SimpleMessageAttributes sm=new SimpleMessageAttributes(greenMail.getReceivedMessages()[0],greenMail.getReceivedMessages()[0].getReceivedDate());
	       for(Address a:greenMail.getReceivedMessages()[0].getAllRecipients())
	         System.out.println(sm.parseAddress(a.toString()));
	         
	//             greenMail.stop();
	        
	}

}
