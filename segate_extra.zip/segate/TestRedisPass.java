package DeriveRegex;

import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;

public class TestRedisPass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RedisAutoConfiguration rc=new RedisAutoConfiguration();
		JedisConnectionFactory factory=new JedisConnectionFactory();
		rc.testingURLconf(factory);
	}

}
