package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.commons.io.FilenameUtils;

import com.google.common.io.Files;

public class TestConcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//IO-552
		System.out.println(FilenameUtils.concat("\\top","~ AA.PPAPZs-~4_\\Z/"));//should concat these with a path sep
	}

	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				writeToFile(fname,s+"\t-->\t"+FilenameUtils.concat("\\top",s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
