package DeriveRegex;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

import org.apache.commons.io.FilenameUtils;

import com.google.common.io.Files;

public class TestFileColon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//IO-483
		System.out.println(FilenameUtils.getPrefixLength(":."));//should o/p 0
		//System.out.println(FilenameUtils.getPrefixLength("s:"));//should give 0 for unix settings but gives 3 in other null case(assuming windows)
	}
	
	public static void testall(String fname,HashSet<String> teststr)
	{
		boolean append=false;
		Iterator<String> sIt=teststr.iterator();
		while(sIt.hasNext())
		{String s = "";
			try{
				s=sIt.next();
				//System.out.println(Files.getFileExtension(s));
				writeToFile(fname,s+"\t-->\t"+FilenameUtils.getPrefixLength(s)+"\n",append);
				append=true;
			}
			catch(Exception e)
			{
				//System.out.println("Exception"+s+"-->"+e.getMessage());
				writeToFile(fname,"Exception: "+s+"\t-->\t"+e.getMessage()+"\n",append);
				append=true;
			}
		}
	}
	
	static void writeToFile(String fname, String content, boolean append)
	{
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(fname,append))) {
			bw.write(content);
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
