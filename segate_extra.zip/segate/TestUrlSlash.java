package DeriveRegex;

import org.asynchttpclient.uri.Uri;

public class TestUrlSlash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//async-http-client-1110
		Uri context = Uri.create("https://graph.facebook.com");
		Uri url = Uri.create2(context, "!'!#'!$/''!$/#");
		System.out.println(url);
	}

}
