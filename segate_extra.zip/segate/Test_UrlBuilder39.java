package DeriveRegex;

import io.mikael.urlbuilder.UrlBuilder;

public class Test_UrlBuilder39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(UrlBuilder.fromString("http://somehost.com/page/++++"));
		//System.out.println(UrlBuilder.fromString("file:///)!$&'./:=@_+)"));
		
	}

}
