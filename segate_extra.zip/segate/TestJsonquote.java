package DeriveRegex;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class TestJsonquote {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ToStringBuilder.setDefaultStyle(ToStringStyle.JSON_STYLE);
		Integer base = Integer.valueOf(5);
		System.out.println((new ToStringBuilder(base)).append("name","Let's \"quote\" this"));
	}

}
